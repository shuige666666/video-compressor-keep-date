/**
 * 逐帧画质评分：原片同帧为参考，全分辨率计算 PSNR / SSIM，VMAF 用 4K 模型、原生分辨率。
 * 帧对齐按显示帧序号（setpts=N），与时间戳核对相互独立。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, run, LOGS, METRICS, ensureDirs, fmt } from './lib.mjs';

const argv = process.argv.slice(2);
const clipFilter = argv.filter((a) => /^C\d$/.test(a));
const onlyLabel = argv.includes('--label') ? argv[argv.indexOf('--label') + 1] : null;
// 编码测速结束后才评分，可按分片并行以缩短墙钟时间（不影响任何编码计时）
const shardArg = argv.includes('--shard') ? argv[argv.indexOf('--shard') + 1] : null;
const [shardIdx, shardN] = shardArg ? shardArg.split('/').map(Number) : [0, 1];
let fileSeq = 0;

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
await ensureDirs();

const GRAPH = (psnrLog, ssimLog, vmafLog) => [
  '[0:v]settb=1/1000,setpts=N,format=yuv420p,split=3[r1][r2][r3]',
  '[1:v]settb=1/1000,setpts=N,format=yuv420p,split=3[d1][d2][d3]',
  `[d1][r1]psnr=stats_file=${psnrLog}:shortest=1[o1]`,
  `[d2][r2]ssim=stats_file=${ssimLog}:shortest=1[o2]`,
  `[d3][r3]libvmaf=model=version=vmaf_4k_v0.6.1:log_fmt=json:log_path=${vmafLog}:n_threads=8:shortest=1[o3]`,
].join(';');

function parsePsnr(log) {
  const rows = [];
  for (const line of log.split(/\r?\n/)) {
    const m = /n:(\d+).*?psnr_avg:([\d.]+|inf)/.exec(line);
    if (m) rows.push({ n: +m[1] - 1, psnr: m[2] === 'inf' ? 99 : +m[2] });
  }
  return rows;
}
function parseSsim(log) {
  const rows = [];
  for (const line of log.split(/\r?\n/)) {
    const m = /n:(\d+).*?All:([\d.]+)/.exec(line);
    if (m) rows.push({ n: +m[1] - 1, ssim: +m[2] });
  }
  return rows;
}
function stats(values) {
  if (!values.length) return null;
  const s = [...values].sort((a, b) => a - b);
  const avg = values.reduce((a, b) => a + b, 0) / values.length;
  const q = (p) => s[Math.min(s.length - 1, Math.max(0, Math.floor(p * (s.length - 1))))];
  return { avg, min: s[0], p1: q(0.01), p5: q(0.05), p50: q(0.5), max: s[s.length - 1] };
}

for (const clip of manifest.clips.filter((c) => !clipFilter.length || clipFilter.includes(c.id))) {
  const encDir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`, '编码结果');
  let files = (await fs.readdir(encDir)).filter((f) => f.endsWith('.mp4')).sort();
  if (onlyLabel) files = files.filter((f) => f.includes(onlyLabel));

  for (const f of files) {
    fileSeq++;
    if (shardN > 1 && (fileSeq - 1) % shardN !== shardIdx) continue;
    const label = path.basename(f, '.mp4');
    const outJson = path.join(METRICS, `${clip.id}-${label}.json`);
    if (!argv.includes('--force') && await fs.stat(outJson).then(() => true).catch(() => false)) {
      console.log(`${clip.id} ${label.padEnd(28)} 已存在，跳过`);
      continue;
    }
    const enc = path.join(encDir, f);
    const wdRel = 'metrics/tmp';
    await fs.mkdir(path.join(ROOT, wdRel), { recursive: true });
    // 滤镜选项里的路径必须是相对路径：绝对路径的盘符冒号会被当作参数分隔符
    const rel = (name) => `${wdRel}/${clip.id}-${label}-${name}`;
    const psnrLog = path.join(ROOT, rel('psnr.log'));
    const ssimLog = path.join(ROOT, rel('ssim.log'));
    const vmafLog = path.join(ROOT, rel('vmaf.json'));

    const args = ['-y', '-hide_banner', '-loglevel', 'error',
      '-ss', Math.max(0, clip.segment.startPts - 0.0005).toFixed(6), '-i', clip.src,
      '-i', enc,
      '-lavfi', GRAPH(rel('psnr.log'), rel('ssim.log'), rel('vmaf.json')),
      '-map', '[o1]', '-frames:v', String(clip.segment.frames), '-f', 'null', '-',
      '-map', '[o2]', '-frames:v', String(clip.segment.frames), '-f', 'null', '-',
      '-map', '[o3]', '-frames:v', String(clip.segment.frames), '-f', 'null', '-'];

    const started = Date.now();
    const r = await run(FF, args, { cwd: ROOT });
    if (r.code !== 0) {
      console.error(`${clip.id}/${label} 评分失败: ${r.stderr.slice(-500)}`);
      continue;
    }
    const psnr = parsePsnr(await fs.readFile(psnrLog, 'utf8'));
    const ssim = parseSsim(await fs.readFile(ssimLog, 'utf8'));
    const vmafRaw = JSON.parse(await fs.readFile(vmafLog, 'utf8'));
    const vmaf = vmafRaw.frames.map((x) => ({ n: x.frameNum, vmaf: x.metrics.vmaf }));

    const perFrame = psnr.map((p, i) => ({
      n: p.n, psnr: p.psnr, ssim: ssim[i]?.ssim ?? null, vmaf: vmaf[i]?.vmaf ?? null,
    }));

    if (perFrame.length !== clip.segment.frames) {
      console.error(`${clip.id}/${label} 评帧数异常 ${perFrame.length} ≠ ${clip.segment.frames}`);
    }
    const rec = {
      clip: clip.id, label, frames: perFrame.length, elapsedMs: Date.now() - started,
      model: { vmaf: 'vmaf_4k_v0.6.1', resolution: `${clip.displayWidth}x${clip.displayHeight}`, subsample: 1, alignment: 'frame-index' },
      psnr: stats(perFrame.map((x) => x.psnr)),
      ssim: stats(perFrame.map((x) => x.ssim).filter((x) => x != null)),
      vmaf: stats(perFrame.map((x) => x.vmaf).filter((x) => x != null)),
      perFrame,
    };
    await fs.writeFile(outJson, JSON.stringify(rec), 'utf8');

    // 逐帧明细 CSV，便于定位薄弱时间段
    const csv = ['frame,psnr,ssim,vmaf', ...perFrame.map((x) => `${x.n},${x.psnr.toFixed(4)},${(x.ssim ?? 0).toFixed(6)},${(x.vmaf ?? 0).toFixed(4)}`)].join('\n');
    await fs.writeFile(path.join(METRICS, `${clip.id}-${label}.csv`), csv, 'utf8');

    console.log(`${clip.id} ${label.padEnd(28)} PSNR ${fmt(rec.psnr.avg)} (min ${fmt(rec.psnr.min)}) | SSIM ${rec.ssim.avg.toFixed(5)} | VMAF4K ${fmt(rec.vmaf.avg)} (p5 ${fmt(rec.vmaf.p5)}, min ${fmt(rec.vmaf.min)}) | ${fmt(rec.elapsedMs / 1000, 1)}s`);
  }
}
console.log('\n评分完成');
