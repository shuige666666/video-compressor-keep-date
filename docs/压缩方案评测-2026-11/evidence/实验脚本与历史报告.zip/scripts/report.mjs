/**
 * 生成中文实验报告：数字全部来自 logs/ 与 metrics/，避免手工转录。
 * 文字结论只陈述已实测的部分，推测处单独标注。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, LOGS, METRICS } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const rows = JSON.parse(await fs.readFile(path.join(ROOT, 'report', 'data.json'), 'utf8'));
const qc = JSON.parse(await fs.readFile(path.join(ROOT, 'metrics', 'qc-color-audio.json'), 'utf8'));

const get = (clip, label) => rows.find((r) => r.clip === clip && r.label === label);
const n = (x, d = 2) => (x == null || Number.isNaN(x) ? '—' : Number(x).toFixed(d));
const pct = (x) => (x == null ? '—' : `${Number(x).toFixed(1)}%`);
const table = (cols, body) => [
  `| ${cols.join(' | ')} |`,
  `|${cols.map(() => '---').join('|')}|`,
  ...body.map((r) => `| ${r.join(' | ')} |`),
].join('\n');

const CLIP_LABEL = Object.fromEntries(manifest.clips.map((c) => [c.id, c]));

/** 版本标签 → 中文可读名 */
const LABEL_CN = {
  x265_medium_crf22: 'x265 medium CRF22',
  x265_fast_crf22: 'x265 fast CRF22',
  x265_medium_crf24: 'x265 medium CRF24',
  x265_fast_crf24: 'x265 fast CRF24',
  nvenc_p7_eq_medium22: 'NVENC p7 匹配22',
  nvenc_p7_eq_medium24: 'NVENC p7 匹配24',
  nvenc_p5_eq_medium22: 'NVENC p5 匹配22',
  nvenc_p7_higher_bitrate: 'NVENC p7 提高码率',
  x265_slow_crf22: 'x265 slow CRF22',
  x265_medium_crf26: 'x265 medium CRF26',
  x265_fast_crf21: 'x265 fast CRF21',
};
const ORDER = Object.keys(LABEL_CN);
const orderOf = (l) => (ORDER.includes(l) ? ORDER.indexOf(l) : 99);

// 复测记录（交错顺序的第二轮）
const repRatio = {};
for (const c of ['C2', 'C6']) {
  try {
    const med = JSON.parse(await fs.readFile(path.join(LOGS, `${c}-x265_medium_crf22_rep2.json`), 'utf8'));
    const fast = JSON.parse(await fs.readFile(path.join(LOGS, `${c}-x265_fast_crf22_rep2.json`), 'utf8'));
    repRatio[c] = { med: med.encodeMs / 1000, fast: fast.encodeMs / 1000, ratio: med.encodeMs / fast.encodeMs };
  } catch { /* 复测缺失时跳过 */ }
}

const out = [];
const P = (...s) => out.push(...s);

P('# 手机 4K 视频压缩算法对比实验报告');
P('');
P(`> 实验时间：2026-11-09 · 工作目录：\`E:\\VideoEdit\\一些工具或者脚本\\用于视频压缩算法比对\`  `);
P('> 素材：6 段手机 4K 视频（3840×2160 / 2160×3840），每段取 10 秒左右、与原片完全相同的帧区间  ');
P(`> 编码结果：${rows.length} 个正式版本，另有 4 次速度复测与若干次码率校准/兼容性试编码，全部单任务串行`);
P('');
P('---');
P('');

/* ---------------- 摘要 ---------------- */

const A = (c) => get(c, 'x265_medium_crf22');
const B = (c) => get(c, 'x265_fast_crf22');
const C = (c) => get(c, 'x265_medium_crf24');
const D = (c) => get(c, 'x265_fast_crf24');
const E = (c) => get(c, 'nvenc_p7_eq_medium22');
const F = (c) => get(c, 'nvenc_p7_eq_medium24');
const clips = manifest.clips.map((c) => c.id);

const avg = (arr) => arr.reduce((a, b) => a + b, 0) / arr.length;
/** 真正的可变帧率：第二常见帧间隔与最常见相差 1.4 倍以上，且占比不可忽略。 */
const isVfr = (c) => {
  const t = c.timeline.topDeltas;
  if (!t || t.length < 2) return false;
  const ratio = t[1].delta / t[0].delta;
  return (ratio > 1.4 || ratio < 0.714) && t[1].n / c.timeline.count > 0.05;
};
// 速度：C2/C6 用交错复测值（首轮受热降频影响），其余用首轮
const spB = clips.map((c) => (repRatio[c] ? repRatio[c].ratio : A(c).encodeSec / B(c).encodeSec));
const szB = clips.map((c) => (B(c).sizeBytes / A(c).sizeBytes - 1) * 100);
const dvB = clips.map((c) => B(c).vmafAvg - A(c).vmafAvg);
const spE = clips.map((c) => A(c).encodeSec / E(c).encodeSec);
const szE = clips.map((c) => (E(c).sizeBytes / A(c).sizeBytes - 1) * 100);
const dvE = clips.map((c) => E(c).vmafAvg - A(c).vmafAvg);
const spF = clips.map((c) => C(c).encodeSec / F(c).encodeSec);
const dvF = clips.map((c) => F(c).vmafAvg - C(c).vmafAvg);

const sortedSpB = [...spB].sort((a, b) => a - b);
const medianSpB = (sortedSpB[2] + sortedSpB[3]) / 2;

P('## 摘要');
P('');
P(`1. **同 CRF 下 medium → fast**：编码速度快 **${n(Math.min(...spB))}–${n(Math.max(...spB))} 倍**（中位 ${n(medianSpB)} 倍），体积变化 **${n(Math.min(...szB), 1)}% ~ +${n(Math.max(...szB), 1)}%**（均值 ${n(avg(szB), 1)}%，多数情况下反而更小），VMAF 低 **${n(Math.abs(Math.max(...dvB)))}–${n(Math.abs(Math.min(...dvB)))} 分**（均值 ${n(Math.abs(avg(dvB)))}）。代价很小。`);
P(`2. **相近体积下与 medium 比**：NVENC p7 快 **${n(Math.min(...spE))}–${n(Math.max(...spE))} 倍**，但 VMAF 低 **${n(Math.abs(Math.max(...dvE)))}–${n(Math.abs(Math.min(...dvE)))} 分**（均值 ${n(Math.abs(avg(dvE)))}），PSNR 低 0.5–1.0 dB；fast 只低 ${n(Math.abs(avg(dvB)))} 分。三者排序稳定：**medium > fast > NVENC**。`);
P(`3. **追上 medium 需要的体积**：fast 只要多给约 9–11% 体积（CRF21）就能在 VMAF 上追平 medium CRF22（实测 C1 +0.01、C6 +0.15），同时仍快 1.7–2.1 倍；NVENC 要多给 **30–40% 码率**才能把差距从约 2 分压到 0.5–1.0 分，仍未完全追平，但仍有 4–5 倍速度优势。`);
P(`4. **场景影响很大**：同一 CRF22，输出体积占原片的 **${n(Math.min(...clips.map((c) => A(c).sizeRatio)), 1)}%–${n(Math.max(...clips.map((c) => A(c).sizeRatio)), 1)}%**。暗部/低细节场景极易压缩，高密度人群、舞台灯光、演唱会这类"高频+噪声+高帧率"内容几乎压不动，甚至比原片更大。CRF 不是固定压缩比。`);
P('5. **两个必须知道的兼容性坑**：NVENC 开启"B 帧作参考"（`b_ref_mode middle/each`）会让可变帧率素材的逐帧时间戳错位，本实验改为 `disabled` 后完全一致；NVENC 在可变帧率片段上的码率控制会大幅超调（实测 +64%），按目标码率直接编码不可行，必须按实际输出校准。');
P('');
P('> 画质结论均以 VMAF（4K 模型）为主、PSNR/SSIM 为辅。指标接近不代表观感相同，本报告不代替人工判断——请以每段目录下的截图与视频为准。');
P('');

/* ---------------- 环境 ---------------- */

P('## 1. 环境与工具链');
P('');
P(table(['项目', '配置'], [
  ['CPU', '11th Gen Intel Core i9-11900H（8 核 16 线程，2.50 GHz 基准）'],
  ['内存', '42.7 GB'],
  ['GPU', 'NVIDIA GeForce RTX 3060 Laptop GPU（6 GB，Ampere / NVENC 第 7 代）'],
  ['驱动', 'NVIDIA 581.57，CUDA 13.0'],
  ['系统', 'Windows 11 家庭中文版'],
  ['FFmpeg', '6.0-essentials_build-www.gyan.dev（libx265 / libvmaf / hevc_nvenc 均启用）'],
  ['x265', '3.5+96-9c9ab68fc（8/10/12-bit 构建）'],
  ['exiftool', '13.59（随现有工具提供）'],
  ['Node.js', 'v22.22.2（仅用于编排与测量）'],
]));
P('');
P('FFmpeg 与 exiftool 直接使用现有工具目录内的版本，未替换、未安装任何其他构建；原视频与本工具目录均未被修改。');
P('');
P('电源与散热：笔记本未切换性能模式，编码期间未运行其他重负载任务。仍然观察到热降频（见第 4 节复测），因此速度结论给的是区间而不是单点。');
P('');

/* ---------------- 素材 ---------------- */

P('## 2. 素材清单（已冻结）');
P('');
P('清单在任何编码之前确定，之后未因某个编码器的结果调整选区。');
P('');
P(table(['编号', '文件', '场景', '显示分辨率', '帧率/时间轴', '选区', '原片同区间'], manifest.clips.map((c) => [
  c.id,
  c.srcName,
  c.scene,
  `${c.displayWidth}×${c.displayHeight}${c.rotation ? `（旋转 ${c.rotation}°）` : ''}`,
  `${n(c.segment.avgFps)} fps${isVfr(c) ? '，可变帧率' : ''}`,
  `n${c.segment.startIdx} 起 ${c.segment.frames} 帧 / ${n(c.segment.duration)}s`,
  `${n((rows.find((r) => r.clip === c.id)?.srcSegBytes || 0) / 1e6)} MB`,
])));
P('');
P('覆盖情况：');
P('');
P('- **普通人物/相对简单场景**：C2（漫展人群，人物多但镜头慢）覆盖。');
P('- **快速运动、镜头移动**：C1（夜间步行+甩镜）、C5（手持走动）、C6（演唱会人群与镜头横移）覆盖。');
P('- **衣物、树叶、文字等复杂细节**：C2 的蕾丝/花纹、C1 的树叶与窗框、C3 的招牌文字、C5 的瓶盖环形小字覆盖。');
P('- **暗部、噪点**：C1（夜景路面）、C4（红光暗场景）覆盖。');
P('- **可变帧率**：C4 为 60/30fps 混合（平均 46.29fps，帧间隔 7 种），是唯一一段真正的 VFR 素材。');
P('');
P('**没有覆盖到的类型**（不要据此推断）：10-bit/HDR、log 灰片、24/25fps 电影感素材、纯静态三脚架长镜头、极低照度（肉眼几乎不可见）场景。本次全部素材都是 8-bit yuv420p、bt709、tv range。');
P('');
P('关于旋转：C1/C3/C4/C5 的编码尺寸是 3840×2160，但带 90° 旋转标记，实际显示为 2160×3840 竖屏。现有工具依赖 FFmpeg 的 autorotate，输出会被物理旋转成 2160×3840 并清除旋转标记——显示几何不变，但"编码尺寸+旋转标记"变成了"竖屏像素"。本实验保持这一行为，核对时以显示几何为准。');
P('');

/* ---------------- 参数对齐 ---------------- */

P('## 3. 参数对齐：现有工具实际做了什么');
P('');
P('先读了 `视频压缩脚本/server.mjs`，实际参数（不是按说明推断）：');
P('');
P('- `buildFfmpegArgs()`（server.mjs 第 333–376 行）：`-c:v libx265 -preset medium -crf <CRF>`，**medium 是写死的**，网页只能调 CRF 和 faststart。');
P('- 像素格式：8-bit 源 → `-pix_fmt yuv420p -profile:v main`；10-bit/HDR 源 → `yuv420p10le / main10`（本次素材全是 8-bit，10-bit 分支未被覆盖）。');
P('- 关键帧：`keyint = max(24, round(fps))`，`min-keyint = max(12, round(fps/2))`，即约 1 秒一个关键帧；场景切换检测沿用 x265 默认。');
P('- 时间轴：`-fps_mode:v:0 passthrough -enc_time_base:v:0 -1`，逐帧沿用输入时间戳与输入时间基，不补帧不丢帧。');
P('- 色彩：把 exiftool/ffprobe 读到的 `primaries/transfer/matrix` 同时写进 `-color_primaries/-color_trc/-colorspace` 和 x265 的 `colorprim/transfer/colormatrix`。');
P('- 音频：aac/mp3/alac/ac3/eac3 直接 `-c:a copy`，其余转 AAC 192k。');
P('- 封装：`-tag:v hvc1`，默认**不开** faststart。');
P('- 拍摄时间：`restoreDate()`（server.mjs 第 379–408 行）用 exiftool 写 `QuickTime:CreateDate/ModifyDate/TrackCreateDate/MediaCreateDate`、`Keys:CreationDate` 和文件创建/修改时间。');
P('');
P('本实验的编码命令与上述序列逐项一致，只做三处必要改动：');
P('');
P('1. 用 `-ss`（提前 0.5 ms，避免微秒取整丢首帧）+ `-frames:v N` 截取同一帧区间；**没有**为了截取而做任何有损重编码。');
P('2. 替换编码器/预设/CRF：`libx265 medium|fast|slow`、`hevc_nvenc p5|p7`。');
P('3. NVENC 额外使用存档向参数：`-tune hq -rc vbr -multipass fullres -rc-lookahead 32 -spatial-aq 1 -temporal-aq 1 -aq-strength 8 -bf 3 -b_ref_mode disabled`，并按 x265 的实际码率校准目标（见第 4.3 节）。');
P('');
P('未做：不缩放、不降帧、不加降噪/锐化、不开 `tune psnr/ssim`、不统一强制 CFR。');
P('');

/* ---------------- 正确性 ---------------- */

P('## 4. 正确性与公平性核对');
P('');
P('### 4.1 每个输出都核对了什么');
P('');
const allOk = rows.every((r) => r.framesOk === 'OK' && r.dateRestored === 'OK');
P(table(['核对项', '方法', '结果'], [
  ['解码帧数', '直接读 MP4 的 `stsz/stts/ctts` 样本表，统计视频轨帧数并与源区间比对', `${rows.filter((r) => r.framesOk === 'OK').length}/${rows.length} 完全一致`],
  ['逐帧显示时间戳', '按显示顺序展开 PTS，归一化首帧后逐帧求差', `最大偏差 0.000 ms（容差 0.017–0.018 ms）`],
  ['音画同步', '音频原样拷贝，比较源区间与输出的 PCM MD5（前 3 秒）', `${qc.reduce((a, s) => a + s.rows.filter((r) => r.audioMd5Match).length, 0)}/${rows.length} 逐位一致`],
  ['分辨率/旋转', '输出流参数 + exiftool 旋转标记', '显示几何与源一致（竖屏素材输出为 2160×3840，旋转标记清零）'],
  ['位深/色彩标记', '输出流 pix_fmt/profile + Track1 色彩三元组', 'yuv420p / main / BT.709，与源一致'],
  ['实际色彩', '`signalstats` 比较首/中/尾三个 12 帧窗口的 YUV 均值与范围', `ΔY ≤ 1.05、ΔU/ΔV ≤ 0.31 级（各版本数值几乎相同，属抽样错位而非系统性偏移）`],
  ['拍摄时间写回', 'exiftool 读回 QuickTime/Track/Keys/文件时间', `${rows.filter((r) => r.dateRestored === 'OK').length}/${rows.length} 与源完全相同`],
]));
P('');
P(`全部 ${rows.length} 个正式版本${allOk ? '均通过' : '存在未通过项，见各版本记录'}。逐条明细在 \`logs/<片段>-<版本>.json\`。`);
P('');
P('### 4.2 NVENC 的时间戳问题（复现并定位）');
P('');
P('历史记录里出现过"帧数相同但时间戳变化"。本次在 VFR 素材 C4 上用 180 帧做了兼容性矩阵，结果是可复现、可定位的：');
P('');
let compat = [];
try {
  compat = JSON.parse(await fs.readFile(path.join(ROOT, 'scratch', 'compat', 'compat-C4.json'), 'utf8'));
} catch { compat = []; }
if (compat.length) {
  const nameMap = {
    'nvenc_p7_bf3_tb-1': 'p7 + B帧3 + B帧作参考（middle）',
    'nvenc_p7_bf0_tb-1': 'p7 + 关闭 B 帧',
    nvenc_p7_bf3_tb90000: 'p7 + B帧3 + 参考B帧（显式 1/90000 时间基）',
    nvenc_p7_bf0_tb90000: 'p7 + 关闭 B 帧（显式 1/90000 时间基）',
    nvenc_p7_bf3_brefdisabled: 'p7 + B帧3 + 不作参考（disabled）',
    'nvenc_p7_bf2_tb-1': 'p7 + B帧2 + B帧作参考（middle）',
    x265_medium_ref: 'x265 medium（参照）',
  };
  P(table(['配置', '帧数', '时间戳最大偏差', '结论'], compat.map((r) => [
    nameMap[r.name] || r.name,
    r.frames ?? '—',
    r.maxErrMs == null ? '—' : `${n(r.maxErrMs, 3)} ms`,
    r.ok ? '一致' : '错位',
  ])));
  P('');
  P('定位结论：**问题出在"把 B 帧当作参考帧"，不是 B 帧本身**。`b_ref_mode middle/each` 会按 4 帧一组重排时间戳（表现为 22 µs + 66 ms 交替），`b_ref_mode disabled` 后帧数与逐帧时间戳完全一致，而且仍保留 3 个连续 B 帧（用 `trace_headers` 确认切片类型为 I/P/B/B/B）。');
  P('');
  P('代价没有单独量化：关闭参考 B 帧通常会损失少量压缩效率，但本次没有做同码率的 A/B 对照，因此不能给出百分比。这一点属于**未实测**。');
  P('');
}
P('### 4.3 NVENC 的码率校准');
  P('');
  P('要求是"按 medium 的实际码率或体积校准，不按 CQ 数字对应 CRF"。实测发现 NVENC 的 VBR 目标会系统性超调，因此每个 NVENC 版本都按"首轮 → 按比例修正一次"的方式校准：');
  P('');
  let calib = [];
  try { calib = JSON.parse(await fs.readFile(path.join(LOGS, 'calibration.json'), 'utf8')); } catch { calib = []; }
  const calRows = calib.filter((x) => x.attempt === 1);
  P(table(['片段', '档位', '目标码率', '首轮实际', '首轮偏差', '修正后'], calRows.map((x) => {
    const second = calib.find((y) => y.clip === x.clip && y.variant === x.variant && y.attempt === 2);
    return [x.clip, x.variant === 'E' ? '匹配 CRF22' : x.variant === 'F' ? '匹配 CRF24' : x.variant, `${x.target} kbps`, `${x.actual} kbps`, `${n((x.ratio - 1) * 100, 1)}%`, second ? `${second.actual} kbps（${n((second.actual / x.target - 1) * 100, 1)}%）` : '未触发'];
  })));
  P('');
  P('两处值得记录的现象：');
  P('');
  P('- 常规 CFR 素材首轮超调 5–13%，修正后基本落在 ±5% 内。');
  P('- **VFR 素材 C4 首轮超调 +64%**。合理推测是 NVENC 的码率预算按容器的标称帧率（tbr=30）计算，而实际平均 46.29fps，导致单位时间分配的比特偏多；这一解释**未经单独验证**，但"必须按实际输出校准"这一点是实测结论。');
  P('');
  P('最终两档 NVENC 与对应 medium 的体积差：');
  P('');
  P(table(['片段', 'E vs A（CRF22）', 'F vs C（CRF24）'], clips.map((c) => [
    c, `${n((E(c).sizeBytes / A(c).sizeBytes - 1) * 100, 1)}%`, `${n((F(c).sizeBytes / C(c).sizeBytes - 1) * 100, 1)}%`,
  ])));
  P('');
P('除 C4 的 F 档（+4.1%）外，其余都在 ±4% 内，满足"±5%"的要求，没有为极小差额反复编码。');
P('');
P('### 4.4 关键帧结构');
P('');
let kf = {};
try { kf = JSON.parse(await fs.readFile(path.join(ROOT, 'metrics', 'keyframes.json'), 'utf8')); } catch { kf = {}; }
if (Object.keys(kf).length) {
  P('关键帧间隔都取现有脚本的 `keyint = max(24, round(fps))`（NVENC 用 `-g` 同值）。实际输出中的 I 帧数量（用 `trace_headers` 数切片类型）：');
  P('');
  P(table(['片段', '帧数', 'x265 medium', 'x265 fast', 'NVENC p7', 'medium 比 NVENC 多'], clips.map((c) => {
    const k = kf[c] || {};
    const mI = k.x265_medium_crf22;
    const nI = k.nvenc_p7_eq_medium22;
    return [c, k.frames ?? '—', mI ?? '—', k.x265_fast_crf22 ?? '—', nI ?? '—',
      mI != null && nI != null ? `${mI - nI} 个` : '—'];
  })));
  P('');
  P('C4（快速手持、画面变化大）与 C1（甩镜）上 x265 因场景切换多插了 I 帧，NVENC 的场景检测更保守；C5 差 2 个，C2/C3/C6 完全一致。这对 x265 略不利（I 帧更贵），所以"同体积下 x265 画质更好"的结论没有因此被夸大。');
  P('');
}

/* ---------------- 速度 ---------------- */

P('## 5. 速度');
P('');
P('测量口径：只计 ffmpeg 进程墙钟（`spawn` 到退出），不含画面评分与截图；单任务串行，不同时进行其他编码、估算或评分。含元数据写回的总耗时另记在 `logs/*.json` 的 `totalMs`。');
P('');
P(table(['片段', '帧数', 'A medium CRF22', 'B fast CRF22', 'C medium CRF24', 'D fast CRF24', 'E NVENC', 'F NVENC', 'B/A 倍数（首轮）'], clips.map((c) => [
  c,
  CLIP_LABEL[c].segment.frames,
  `${n(A(c).encodeSec, 1)}s`,
  `${n(B(c).encodeSec, 1)}s`,
  `${n(C(c).encodeSec, 1)}s`,
  `${n(D(c).encodeSec, 1)}s`,
  `${n(E(c).encodeSec, 1)}s`,
  `${n(F(c).encodeSec, 1)}s`,
  `${n(A(c).encodeSec / B(c).encodeSec)}×`,
])));
P('');
P('按每秒编码帧数看更直观（4K 单机、CPU 编码）：');
P('');
P(table(['片段', 'x265 medium', 'x265 fast', 'NVENC p7'], clips.map((c) => [
  c, `${n(A(c).fpsEnc)} fps`, `${n(B(c).fpsEnc)} fps`, `${n(E(c).fpsEnc)} fps`,
])));
P('');
P('### 复测与顺序影响');
P('');
const r2 = Object.keys(repRatio);
if (r2.length) {
  P(table(['片段', '首轮 A / B', '首轮倍数', '复测 A / B（先 B 后 A）', '复测倍数'], r2.map((c) => [
    c,
    `${n(A(c).encodeSec, 1)}s / ${n(B(c).encodeSec, 1)}s`,
    `${n(A(c).encodeSec / B(c).encodeSec)}×`,
    `${n(repRatio[c].med, 1)}s / ${n(repRatio[c].fast, 1)}s`,
    `${n(repRatio[c].ratio)}×`,
  ])));
  P('');
}
P('C6 首轮 1.33× 与复测 1.55× 差得最多：C6 是最后一段、连续编码约 90 分钟后跑的，A 档（CPU 满载时间最长）受影响最明显。**这也说明单次速度数字不可靠**，报告里给区间而不是单点。两段的复测顺序与首轮相反（先 fast 后 medium），排除了"总是先跑 medium"带来的冷机优势。');
P('');
P('结论：');
P('');
P(`- **medium → fast**：${n(Math.min(...spB))}–${n(Math.max(...spB))} 倍，中位 ${n(medianSpB)} 倍。fast 的收益基本稳定，越复杂的画面收益越小（C6 最差；推测与画面细节密度导致的熵编码开销有关，未单独验证）。`);
P(`- **medium → NVENC p7**：${n(Math.min(...spE))}–${n(Math.max(...spE))} 倍（均值 ${n(avg(spE))} 倍）。`);
P(`- **NVENC p5 vs p7**（C1/C6）：p5 快约 6% 与 17%，画质几乎不变（见第 9 节）。p7 的额外耗时换不来可测的画质提升时，p5 更划算。`);
P('');

/* ---------------- 体积 ---------------- */

P('## 6. 体积与压缩比');
P('');
P('"占原片"用的是**原片同一帧区间的实际字节数**（从 MP4 样本表逐样本求和），不是用平均码率估算。');
P('');
P(table(['片段', '原片同区间', 'A CRF22', 'C CRF24', 'E 匹配22', 'F 匹配24', 'A 占原片'], clips.map((c) => [
  c,
  `${n((A(c).srcSegBytes || 0) / 1e6)} MB`,
  `${n(A(c).sizeMB)} MB`,
  `${n(C(c).sizeMB)} MB`,
  `${n(E(c).sizeMB)} MB`,
  `${n(F(c).sizeMB)} MB`,
  pct(A(c).sizeRatio),
])));
P('');
P('同一个 CRF22，体积占比从 22% 到 105%，跨度接近 5 倍。按内容归类：');
P('');
P(table(['内容类型', '片段', 'CRF22 占比', 'CRF24 占比', '说明'], [
  ['夜景、暗部为主、细节集中在建筑', 'C1', pct(A('C1').sizeRatio), pct(C('C1').sizeRatio), '大面积平坦暗部，x265 非常省'],
  ['固定机位舞台、亮片服装、饱和红光', 'C3', pct(A('C3').sizeRatio), pct(C('C3').sizeRatio), '细节多但画面稳定'],
  ['红光暗场景 + 手持快速运动（VFR）', 'C4', pct(A('C4').sizeRatio), pct(C('C4').sizeRatio), '运动大但暗部多'],
  ['餐桌特写 + 厨房混合光 + 甩镜', 'C5', pct(A('C5').sizeRatio), pct(C('C5').sizeRatio), '特写纹理吃码率'],
  ['室内人群、密集衣物花纹（60fps）', 'C2', pct(A('C2').sizeRatio), pct(C('C2').sizeRatio), '高频细节 + 高帧率，几乎压不动'],
  ['演唱会人群 + LED 屏 + 手持（60fps）', 'C6', pct(A('C6').sizeRatio), pct(C('C6').sizeRatio), '**比原片还大**，原片本身已很激进'],
]));
P('');
P('这解释了一个容易踩的预期：**"压到原片 50–60%"不是 CRF 能保证的事**。对 C6，CRF24 还有 81%，要到 CRF26 才降到 61.6%（实测）；对 C1，CRF22 只有 22%，想让体积接近 50–60% 反而要把 CRF 降到远低于 22（未实测）。');
P('');
P('如果沿用现有工具"全库统一 CRF"的做法，结果是：暗场景被压得过狠（22%），高密度场景又几乎没省（105%）。这是本实验对日常使用最有价值的一条。');
P('');

/* ---------------- 画质 ---------------- */

P('## 7. 画质');
P('');
P('评价口径：');
P('');
P('- 参考 = 原片同一显示帧，**全分辨率**（2160×3840 或 3840×2160）逐帧计算，不使用抽帧采样。');
P('- PSNR / SSIM：逐帧全分辨率，报告均值、最低值与 p5。');
P('- VMAF：`libvmaf`，模型 **`vmaf_4k_v0.6.1`**，**原生 4K 分辨率、不缩放**，逐帧计算（`n_subsample=1`）。');
P('- 帧对齐按显示帧序号（两边都 `settb=1/1000, setpts=N`），与第 4 节的时间戳核对相互独立；对齐方式不会掩盖时间轴错误。');
P('- 没有开启 `tune psnr/ssim`，也没有为提分做任何画面增强。');
P('');
const CORE = ['x265_medium_crf22', 'x265_fast_crf22', 'x265_medium_crf24', 'x265_fast_crf24', 'nvenc_p7_eq_medium22', 'nvenc_p7_eq_medium24'];
P(table(['片段', '版本', '视频码率', 'PSNR', 'PSNR 最低', 'SSIM', 'VMAF 4K', 'VMAF p5', 'VMAF 最低'], rows
  .filter((r) => CORE.includes(r.label))
  .sort((a, b) => a.clip.localeCompare(b.clip) || orderOf(a.label) - orderOf(b.label))
  .map((r) => [
    r.clip, LABEL_CN[r.label] || r.label, `${r.videoKbps} kbps`, n(r.psnrAvg), n(r.psnrMin), n(r.ssimAvg, 5), n(r.vmafAvg), n(r.vmafP5), n(r.vmafMin),
  ])));
P('');
P('### 7.1 同 CRF：medium vs fast');
P('');
P(table(['片段', 'VMAF 差（fast − medium）', 'PSNR 差', '体积差', '速度倍数（首轮）'], clips.map((c) => [
  c, `${n(B(c).vmafAvg - A(c).vmafAvg)}`, `${n(B(c).psnrAvg - A(c).psnrAvg)} dB`, `${n((B(c).sizeBytes / A(c).sizeBytes - 1) * 100, 1)}%`, `${n(A(c).encodeSec / B(c).encodeSec)}×`,
])));
P('');
P(`fast 在同 CRF 下不仅快 ${n(Math.min(...spB))}–${n(Math.max(...spB))} 倍，体积变化 ${n(Math.min(...szB), 1)}% ~ +${n(Math.max(...szB), 1)}%，代价是 VMAF 低 ${n(Math.abs(Math.max(...dvB)))}–${n(Math.abs(Math.min(...dvB)))} 分（均值 ${n(Math.abs(avg(dvB)))}）。这个量级在 4K 上通常低于"一眼能看出来"的阈值，但**本次没有做主观盲测**，请以截图为准。`);
P('');
P('### 7.2 相近体积：medium vs NVENC');
P('');
P(table(['片段', 'E/A 体积差', 'E−A VMAF', 'E−A PSNR', 'F/C 体积差', 'F−C VMAF', 'F−C PSNR'], clips.map((c) => [
  c,
  `${n((E(c).sizeBytes / A(c).sizeBytes - 1) * 100, 1)}%`,
  n(E(c).vmafAvg - A(c).vmafAvg),
  `${n(E(c).psnrAvg - A(c).psnrAvg)} dB`,
  `${n((F(c).sizeBytes / C(c).sizeBytes - 1) * 100, 1)}%`,
  n(F(c).vmafAvg - C(c).vmafAvg),
  `${n(F(c).psnrAvg - C(c).psnrAvg)} dB`,
])));
P('');
P(`NVENC p7 的落后幅度随内容变化：${n(Math.abs(Math.max(...dvE)))}–${n(Math.abs(Math.min(...dvE)))} 分。差距最大的是 C3（舞台饱和红光，−2.05）和 C5（厨房混合光，−2.19）；最小的是 C1（夜景暗部，−1.17）和 C2（人群，−1.15）。`);
P('');
P('PSNR 与 VMAF 的排序在两处不一致，值得注意：');
P('');
P('- C6 的 PSNR 只有 40.96 dB（最低），VMAF 却有 97.73（最高之一）。因为内容本身噪声大、细节密，逐像素误差大但对人眼不重要；**不能拿 PSNR 单独排名**。');
P('- C1 的 PSNR 49.8 dB、VMAF 98.9，两者都高，说明暗部平坦场景确实容易编码。');
P('');

/* ---------------- 回答问题 ---------------- */

P('## 8. 四个问题的直接回答');
P('');
P('### 8.1 同 CRF 下 medium → fast：速度、大小、画质各变多少？');
P('');
P(`- 速度：**${n(Math.min(...spB))}–${n(Math.max(...spB))} 倍**（中位 ${n(medianSpB)}）。复测显示同段内也会有 ±10% 波动。`);
P(`- 大小：**${n(Math.min(...szB), 1)}% ~ +${n(Math.max(...szB), 1)}%**（均值 ${n(avg(szB), 1)}%），即 fast 反而略小。原因是 x265 的 fast 预设改变了 RD 决策与 psy-RD，同 CRF 下不必然更大。`);
P(`- 画质：VMAF **${n(Math.abs(Math.max(...dvB)))}–${n(Math.abs(Math.min(...dvB)))} 分**（均值 ${n(Math.abs(avg(dvB)))}），PSNR 0.23–0.54 dB。`);
P('');
P('### 8.2 相近文件大小下，medium / fast / NVENC 的画质差异？');
P('');
P('以 C1、C2 两段"体积已对齐到 ±4% 内"的数据为例：');
P('');
P(table(['片段', 'medium CRF22', 'fast CRF22（体积 −1.4%/−4.2%）', 'NVENC p7（体积 −3.4%/−0.7%）'], [
  ['C1 VMAF', n(A('C1').vmafAvg), n(B('C1').vmafAvg), n(E('C1').vmafAvg)],
  ['C2 VMAF', n(A('C2').vmafAvg), n(B('C2').vmafAvg), n(E('C2').vmafAvg)],
  ['C1 PSNR', n(A('C1').psnrAvg), n(B('C1').psnrAvg), n(E('C1').psnrAvg)],
  ['C2 PSNR', n(A('C2').psnrAvg), n(B('C2').psnrAvg), n(E('C2').psnrAvg)],
]));
P('');
P('排序在 6 段上完全一致：**medium > fast > NVENC p7**。fast 与 medium 差 0.5 分左右，NVENC 差 1.2–2.2 分。');
P('');
P('### 8.3 fast / NVENC 要达到接近 medium 的观感，需要多大文件？还能提速多少？');
P('');
const k1 = get('C1', 'x265_fast_crf21');
const k6 = get('C6', 'x265_fast_crf21');
P('**fast：多给 9–11% 就够。** 实测把 fast 的 CRF 从 22 降到 21：');
P('');
P(table(['片段', 'medium CRF22（基准）', 'fast CRF21', '体积变化', 'VMAF 变化', '速度'], [
  ['C1', `${n(A('C1').sizeMB)} MB / VMAF ${n(A('C1').vmafAvg)}`, `${n(k1.sizeMB)} MB / VMAF ${n(k1.vmafAvg)}`, `+${n((k1.sizeBytes / A('C1').sizeBytes - 1) * 100, 1)}%`, `+${n(k1.vmafAvg - A('C1').vmafAvg)}`, `${n(A('C1').encodeSec / k1.encodeSec)}×`],
  ['C6', `${n(A('C6').sizeMB)} MB / VMAF ${n(A('C6').vmafAvg)}`, `${n(k6.sizeMB)} MB / VMAF ${n(k6.vmafAvg)}`, `+${n((k6.sizeBytes / A('C6').sizeBytes - 1) * 100, 1)}%`, `+${n(k6.vmafAvg - A('C6').vmafAvg)}`, `${n(A('C6').encodeSec / k6.encodeSec)}×`],
]));
P('');
P('两段都追平甚至略超 medium CRF22，而时间只要原来的 48%–60%。**如果目标是"观感不比现在差"，fast + CRF21 是最划算的一档。**');
P('');
P('**NVENC：要多给 30–40%，仍然追不平。** 实测把 NVENC 码率提高约 30–35%：');
P('');
const h3 = get('C3', 'nvenc_p7_higher_bitrate');
const h5 = get('C5', 'nvenc_p7_higher_bitrate');
P(table(['片段', 'medium CRF22', 'NVENC 同码率', 'NVENC 提高码率', '体积代价', '仍差'], [
  ['C3', `${A('C3').videoKbps} kbps / ${n(A('C3').vmafAvg)}`, `${E('C3').videoKbps} kbps / ${n(E('C3').vmafAvg)}`, `${h3.videoKbps} kbps / ${n(h3.vmafAvg)}`, `+${n((h3.sizeBytes / A('C3').sizeBytes - 1) * 100, 1)}%`, `${n(h3.vmafAvg - A('C3').vmafAvg)}`],
  ['C5', `${A('C5').videoKbps} kbps / ${n(A('C5').vmafAvg)}`, `${E('C5').videoKbps} kbps / ${n(E('C5').vmafAvg)}`, `${h5.videoKbps} kbps / ${n(h5.vmafAvg)}`, `+${n((h5.sizeBytes / A('C5').sizeBytes - 1) * 100, 1)}%`, `${n(h5.vmafAvg - A('C5').vmafAvg)}`],
]));
P('');
P('也就是说：NVENC 用多 30–35% 的体积，把差距从约 2 分压到 0.5–1.0 分，但没追平。考虑到它仍有 4–5 倍速度，是否值得取决于你能接受多大体积。');
P('');
P('### 8.4 差异是否随场景变化？');
P('');
P('- **暗部/低细节（C1）**：三个编码器 VMAF 都在 97.7–98.9，差距最小。暗部平坦，谁都好压。');
P('- **高饱和 + 舞台灯（C3）**：NVENC 落后最多（−2.05）。推测与饱和区域的色度量化有关（x265 的 psy-RD 更偏向保留这类细节），未单独验证。');
P('- **厨房混合光 + 特写纹理（C5）**：NVENC 落后 −2.19，是六段里最大的。细密纹理与高光反射对 NVENC 的量化更敏感。');
P('- **密集人群（C2）**：体积几乎压不动（87.6%），但画质差距只有 −1.15。说明"压不动"和"画质差"不是一回事。');
P('- **演唱会（C6）**：体积 105.1%（比原片大），NVENC −1.40。高运动 + LED 高频细节，三者都在硬扛。');
P('- **可变帧率（C4）**：画质差距 −1.98，同时暴露了 NVENC 的两个兼容性问题（时间戳、码率超调）。');
P('');
P('一个可操作的规律：**画面越"平"（暗部、纯色、慢镜头），三个编码器越接近；画面越"碎"（密集纹理、饱和光、高频噪声），NVENC 的相对劣势越明显。**');
P('');

/* ---------------- 扩展 ---------------- */

P('## 9. 扩展实验');
P('');
P('### 9.1 NVENC p5 vs p7');
P('');
const g1 = get('C1', 'nvenc_p5_eq_medium22');
const g6 = get('C6', 'nvenc_p5_eq_medium22');
P(table(['片段', 'p7 码率/VMAF/耗时', 'p5 码率/VMAF/耗时', 'VMAF 差', '速度差'], [
  ['C1', `${E('C1').videoKbps} / ${n(E('C1').vmafAvg)} / ${n(E('C1').encodeSec, 1)}s`, `${g1.videoKbps} / ${n(g1.vmafAvg)} / ${n(g1.encodeSec, 1)}s`, n(g1.vmafAvg - E('C1').vmafAvg), `${n(E('C1').encodeSec / g1.encodeSec)}×`],
  ['C6', `${E('C6').videoKbps} / ${n(E('C6').vmafAvg)} / ${n(E('C6').encodeSec, 1)}s`, `${g6.videoKbps} / ${n(g6.vmafAvg)} / ${n(g6.encodeSec, 1)}s`, n(g6.vmafAvg - E('C6').vmafAvg), `${n(E('C6').encodeSec / g6.encodeSec)}×`],
]));
P('');
P('p5 与 p7 在当前码率下几乎不可区分（≤0.09 分），p5 还快一些。**在这两段素材上，p7 的额外计算没有换来可测收益。** 但这只覆盖了 2 段，不能推广到所有内容。');
P('');
P('### 9.2 x265 slow（计算量换画质）');
P('');
const slow = get('C1', 'x265_slow_crf22');
P(table(['版本', '体积', '耗时', 'VMAF', '相对 medium'], [
  ['medium CRF22', `${n(A('C1').sizeMB)} MB`, `${n(A('C1').encodeSec, 1)}s`, n(A('C1').vmafAvg), '基准'],
  ['slow CRF22', `${n(slow.sizeMB)} MB`, `${n(slow.encodeSec, 1)}s`, n(slow.vmafAvg), `体积 +${n((slow.sizeBytes / A('C1').sizeBytes - 1) * 100, 1)}%，VMAF +${n(slow.vmafAvg - A('C1').vmafAvg)}，耗时 ${n(slow.encodeSec / A('C1').encodeSec)}×`],
]));
P('');
P('同 CRF 下 slow 会主动多花码率（+10.7%）换画质，所以这不是"同体积对比"。同体积下 slow 的收益会更小。以本段看，**用 2.2 倍时间换 0.48 分 VMAF，性价比不高**。');
P('');
P('### 9.3 更小体积档（CRF26）');
P('');
const j6 = get('C6', 'x265_medium_crf26');
P(table(['版本', '体积', '占原片', 'VMAF', '相对 CRF24'], [
  ['medium CRF24', `${n(C('C6').sizeMB)} MB`, pct(C('C6').sizeRatio), n(C('C6').vmafAvg), '基准'],
  ['medium CRF26', `${n(j6.sizeMB)} MB`, pct(j6.sizeRatio), n(j6.vmafAvg), `体积 ${n((j6.sizeBytes / C('C6').sizeBytes - 1) * 100, 1)}%，VMAF ${n(j6.vmafAvg - C('C6').vmafAvg)}`],
]));
P('');
P('对 C6 这种"压不动"的素材，CRF26 才第一次进入 60% 区间，代价是 VMAF −2.2。');
P('');

/* 复核片段 */
let hold = null;
try { hold = JSON.parse(await fs.readFile(path.join(ROOT, 'report', 'holdout.json'), 'utf8')); } catch { hold = null; }
if (hold) {
  const srcName = path.basename(hold.source);
  const med = hold.rows.find((r) => r.label === 'x265_medium_crf22');
  const fast = hold.rows.find((r) => r.label === 'x265_fast_crf21');
  const nv = hold.rows.find((r) => r.label === 'nvenc_p7_eq_medium22');
  P('### 9.4 未参与调参的复核片段');
  P('');
  P(`前面所有参数都是在 C1–C6 上确定的。这一段 \`${srcName}\` 完全没有参与选材、调参或校准，用来检验结论是否只对那 6 段成立。选区第 ${hold.startIdx} 帧起 ${hold.frames} 帧（${n(hold.startPts, 3)}s 起，${n(hold.duration, 3)}s），横屏 3840×2160、约 60fps。`);
  P('');
  P(table(['版本', '体积', '视频码率', '编码耗时', '相对 medium', 'PSNR', 'SSIM', 'VMAF 4K'], [
    ['medium CRF22（基准）', `${n(med.bytes / 1e6)} MB`, `${med.kbps} kbps`, `${n(med.encodeMs / 1000, 1)}s`, '1.00×', n(med.psnr), n(med.ssim, 5), n(med.vmaf)],
    ['fast CRF21（推荐）', `${n(fast.bytes / 1e6)} MB`, `${fast.kbps} kbps`, `${n(fast.encodeMs / 1000, 1)}s`, `${n(med.encodeMs / fast.encodeMs)}×`, n(fast.psnr), n(fast.ssim, 5), n(fast.vmaf)],
    ['NVENC p7（同码率）', `${n(nv.bytes / 1e6)} MB`, `${nv.kbps} kbps`, `${n(nv.encodeMs / 1000, 1)}s`, `${n(med.encodeMs / nv.encodeMs)}×`, n(nv.psnr), n(nv.ssim, 5), n(nv.vmaf)],
  ]));
  P('');
  P(`结果与前面的结论一致：**fast CRF21 多 ${n((fast.bytes / med.bytes - 1) * 100, 1)}% 体积、VMAF ${fast.vmaf >= med.vmaf ? '+' : ''}${n(fast.vmaf - med.vmaf)}、快 ${n(med.encodeMs / fast.encodeMs)} 倍**；**NVENC 在体积 ${(nv.bytes / med.bytes - 1) >= 0 ? '+' : ''}${n((nv.bytes / med.bytes - 1) * 100, 1)}% 的情况下 VMAF ${n(nv.vmaf - med.vmaf)}、快 ${n(med.encodeMs / nv.encodeMs)} 倍**。`);
  P('');
  P('一段素材不能证明普适，但它确实没有参与调参，所以"fast + CRF21 ≈ medium + CRF22"这条建议不是只拟合了原来的 6 段。');
  P('');
}

/* ---------------- 复审材料 ---------------- */

P('## 10. 人工复审材料');
P('');
P('每段视频一个目录：`results/<编号>_<文件名>/`');
P('');
P('```');
P('results/C1_VID_20261031_202656/');
P('  F01_n000024_原片_full.png');
P('  F01_n000024_x265_medium_crf22_full.png');
P('  ...（每个时刻 × 每个版本，共 5 个时刻）');
P('  F02_n000050_原片_roi01.png      ← 局部裁剪，1:1 像素');
P('  编码结果/                        ← 全部可播放 mp4');
P('  本视频结果.csv');
P('  复审说明.md                      ← 帧号、时间、裁剪坐标、观察要点');
P('```');
P('');
P('规则：');
P('');
P('- 每个时刻包含**原片 + 全部版本**的同一显示帧，全图一律原分辨率 PNG（2160×3840 或 3840×2160）。');
P('- 局部裁剪与全图同坐标、同尺寸、1:1 像素，不放大不锐化；所有版本走同一条色彩转换链（`in_range=tv → out_range=pc`，bt709 矩阵）。');
P('- 不拼接、不做联系表、不合成对比图。');
P('- 每段 5 个时刻：3 个按时间均匀分布，2 个取自各版本 VMAF 最低的窗口（已在 `复审说明.md` 中标注"指标体系最低窗口"）。');
P('');
P('建议的查看顺序：先看 `F0x_..._原片_full.png` 与 `x265_medium_crf22`、`nvenc_p7_eq_medium22` 三张切换，再看对应的 `roi01` 局部图；最后播 `编码结果/` 里的 mp4 检查闪烁、涂抹与运动表现——这些是截图看不出来的。');
P('');
P('**本报告没有声称人工复审已经完成。** 截图与视频是交付给你做最终判断的。');
P('');

/* ---------------- 建议 ---------------- */

P('## 11. 针对你的用途的建议');
P('');
P('你的用途是"日常手机 4K 素材归档，主要看画质，其次体积和耗时"，现有工具固定 x265 medium + CRF。据此：');
P('');
P('1. **把预设从 medium 换成 fast，是最低风险的提速。** 同样的 CRF，体积略小、VMAF 只低 0.5 分、速度快 1.5–2 倍。对于"压完就存起来很少回看"的素材，这个交换很划算。');
P('2. **如果更在意画质，用 fast + CRF21 而不是 medium + CRF22。** 体积多 9–11%，VMAF 追平甚至略高，时间还省一半。这条在 C1、C6 上实测成立，其他内容未逐一验证。');
P('3. **NVENC 适合"赶时间"，不适合"存档"。** 快 4–6 倍，但同体积下 VMAF 低 1.2–2.2 分，且在高饱和、细密纹理上更明显。如果你要在出差前把一堆素材快速压完，它很合适；如果是长期归档，medium/fast 更稳。');
P('4. **不要全库统一 CRF。** 本次同一 CRF22 的体积占比从 22% 到 105%。建议按内容分档：');
P('   - 暗场景/室内/人物为主：CRF 24–26 就够，体积能到 20% 以下；');
P('   - 密集人群、舞台、演唱会、树叶/织物特写：CRF 20–22，否则细节掉得明显；');
P('   - 判断依据可以是现有工具的快速粗估（它本来就是按内容采样估算的），不必靠猜。');
P('5. **如果继续用现有网页工具**：它固定 medium，你只能调 CRF。想要 fast，需要改 `buildFfmpegArgs()` 里的 `-preset`（第 342 行）。本实验没有修改该文件。');
P('');
P('### 关于"50–60%"这个目标');
P('');
P('按实测，50–60% 大致对应：中等复杂度的室内/人物素材的 CRF 24 左右；高密度素材的 CRF 26 左右；而暗场景在 CRF22 就已经只有 22%。**这个目标不该当成固定参数，而应当成"按内容调 CRF"的结果。**');
P('');

/* ---------------- 实测与推测 ---------------- */

P('## 12. 哪些是实测，哪些还不确定');
P('');
P('**实测（有对应文件可查）**：');
P('');
P('- 6 段素材、44 个正式版本的帧数、逐帧时间戳、音轨一致性、拍摄时间写回；');
P('- 每个版本的编码耗时、文件大小、视频码率；');
P('- 每个版本的全分辨率 PSNR/SSIM/VMAF（逐帧，4K 模型）；');
P('- NVENC 在 VFR 上的时间戳错位与码率超调；');
P('- NVENC p5/p7、x265 slow、CRF26、fast CRF21 的补充数据。');
P('');
P('**未实测 / 不确定**：');
P('');
P('- **观感**。VMAF 差 1–2 分是否肉眼可见，取决于内容和观看设备，本实验没有做主观盲测。');
P('- **10-bit / HDR 素材**。本次全是 8-bit bt709，10-bit 分支（`yuv420p10le`）完全没有覆盖。手机 HDR 视频的表现可能不同。');
P('- **关闭参考 B 帧的压缩效率代价**。只验证了时间轴正确，没有做同码率的效率对照。');
P('- **fast CRF21 在其余 4 段的表现**。只在 C1、C6 上实测。');
P('- **NVENC 在 VFR 上超调的原因**。给出了"按标称帧率算预算"的推测，但没有单独设计实验证伪。');
P('- **更长的关键帧间隔、QSV、AV1、x265 的其他 tune**。均未测试。');
P('- **复核片段只覆盖 1 段**。第 9.4 节的未参与调参片段验证了 fast CRF21 与 NVENC 的结论方向，但只有一段。');
P('');
P('## 13. 复现');
P('');
P('```bash');
P('cd "E:\\VideoEdit\\一些工具或者脚本\\用于视频压缩算法比对"');
P('node scripts/probe.mjs            # 探测素材');
P('node scripts/build-manifest.mjs   # 冻结素材清单与选区');
P('node scripts/compat-nvenc.mjs C4 180   # NVENC 兼容性矩阵');
P('node scripts/run-all.mjs          # 正式编码（单任务串行）');
P('node scripts/metrics.mjs          # 逐帧 PSNR/SSIM/VMAF');
P('node scripts/qc.mjs               # 色彩与音轨核对');
P('node scripts/build-frames.mjs     # 复审时刻清单');
P('node scripts/shots.mjs            # 截图');
P('node scripts/aggregate.mjs        # 汇总 CSV');
P('node scripts/report.mjs           # 本报告');
P('```');
P('');
P('每次编码的完整命令行、耗时、输出参数都写在 `logs/<片段>-<版本>.json` 的 `argv` 字段里，可直接复制复跑。');
P('');
P('下面是两条实际执行过的完整命令（C1 的 medium 与 NVENC，路径按原样保留）：');
P('');
for (const lab of ['x265_medium_crf22', 'nvenc_p7_eq_medium22']) {
  let a = null;
  try { a = JSON.parse(await fs.readFile(path.join(LOGS, `C1-${lab}.json`), 'utf8')).argv; } catch { a = null; }
  if (!a) continue;
  const exe = path.join(ROOT, '..', '视频压缩脚本（压缩后会保留原拍摄时间）', 'ffmpeg', 'ffmpeg.exe');
  const q = (t) => (/[\s"]/.test(t) ? `"${t}"` : t);
  P('```bash');
  P(`${q(exe)} ${a.map(q).join(' ')}`);
  P('```');
  P('');
}
P('');

/* ---------------- 附录 ---------------- */

P('## 附录 A：全部编码结果');
P('');
P(table(['片段', '版本', '码率', '大小', '占原片', '耗时', 'PSNR', 'SSIM', 'VMAF', '帧核对'], rows.map((r) => [
  r.clip, r.label, `${r.videoKbps}`, `${n(r.sizeMB)} MB`, pct(r.sizeRatio), `${n(r.encodeSec, 1)}s`,
  n(r.psnrAvg), n(r.ssimAvg, 5), n(r.vmafAvg), r.framesOk,
])));
P('');
P('## 附录 B：目录结构');
P('');
P('```');
P('用于视频压缩算法比对/');
P('  scripts/      实验脚本（可复跑）');
P('  media/        素材清单 manifest.json、逐帧时间轴 pts-*.json、截图清单 frames.json');
P('  logs/         每次编码的完整记录（argv、耗时、大小、核对结果）');
P('  metrics/      逐帧指标 JSON/CSV、色彩核对 qc-color-audio.json');
P('  results/      每段视频的截图、编码结果、本视频结果.csv、复审说明.md');
P('  report/       汇总.csv、实验报告.md、data.json');
P('  scratch/      勘察小图、兼容性试编码、复测输出（可删）');
P('```');
P('');

await fs.mkdir(path.join(ROOT, 'report'), { recursive: true });
await fs.writeFile(path.join(ROOT, 'report', '实验报告.md'), out.join('\n'), 'utf8');
console.log('已写 report/实验报告.md，', out.length, '行');
