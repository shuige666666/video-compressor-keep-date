/** 冻结素材清单：确定选区、帧数、逐帧时间轴，写入 media/manifest.json。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, probe, timelineStats, keyintFor, fmt } from './lib.mjs';

const BASE1 = 'E:\\VideoEdit\\每天拍几秒企划\\10.25-';
const BASE2 = 'E:\\VideoEdit\\每天拍几秒企划\\9.35-10.24';

/** 先勘察内容再定窗口；此处为最终冻结值。 */
const PICKS = [
  {
    id: 'C1', file: path.join(BASE1, 'VID_20261031_202656.mp4'), start: 5.0, dur: 10.0,
    scene: '夜景步行：单元楼亮窗与树丛细节 → 甩镜运动模糊 → 路面暗部',
    tags: ['暗部', '噪点', '建筑/树叶细节', '甩镜快速运动'],
  },
  {
    id: 'C2', file: path.join(BASE1, 'VID_20261108_204248.mp4'), start: 10.0, dur: 10.0,
    scene: '室内漫展人群：密集人物、衣物花纹与彩色装饰，镜头缓慢横移',
    tags: ['人物', '衣物/花纹细节', '彩色高饱和', '持续运动'],
  },
  {
    id: 'C3', file: path.join(BASE1, 'VID_20261108_211624.mp4'), start: 4.0, dur: 10.0,
    scene: '舞台演出：固定机位，招牌文字、亮片服装，前景观众头部为暗部',
    tags: ['文字', '舞台灯光', '暗部前景', '中等运动'],
  },
  {
    id: 'C4', file: path.join(BASE1, 'VID_20261031_204355.mp4'), start: 0.0, dur: null,
    scene: '红光照明的暗场景，快速手持运动；可变帧率（60/30fps 混合）',
    tags: ['可变帧率', '暗部', '快速运动', '高饱和红'],
  },
  {
    id: 'C5', file: path.join(BASE2, 'VID_20261003_111508.mp4'), start: 4.0, dur: 10.0,
    scene: '餐桌特写（细密纹理与包装文字）→ 甩镜 → 厨房人物与橱柜标签',
    tags: ['细密纹理', '文字', '甩镜运动', '室内混合光'],
  },
  {
    id: 'C6', file: path.join(BASE1, 'VID_20261031_205503.mp4'), start: 5.0, dur: 10.0,
    scene: '演出现场人群：LED 屏文字、密集人头与手臂，镜头持续移动',
    tags: ['LED 文字', '高密度细节', '剧烈运动', '高饱和'],
  },
];

const manifest = { frozenAt: new Date().toISOString(), clips: [] };
await fs.mkdir(path.join(ROOT, 'media'), { recursive: true });

for (const pick of PICKS) {
  const info = await probe(pick.file);
  const tl = await timelineStats(pick.file);
  if (!tl) throw new Error(`${pick.id} 无法读取时间轴`);
  const pts = tl.pts;

  // 选区起点吸附到实际帧时间，并留 0.5ms 余量，避免 -ss 微秒取整把首帧丢掉。
  let startIdx = 0;
  if (pick.start > 0) {
    startIdx = pts.findIndex((p) => p >= pick.start - 1e-9);
    if (startIdx < 0) startIdx = 0;
  }
  const startPts = pts[startIdx];
  const endTarget = pick.dur == null ? Infinity : startPts + pick.dur;
  let frames = 0;
  while (startIdx + frames < pts.length && pts[startIdx + frames] < endTarget - 1e-9) frames++;
  const segPts = Array.from(pts.slice(startIdx, startIdx + frames));
  const norm = segPts.map((p) => Math.round((p - segPts[0]) * 1e9) / 1e9);

  const { keyint, minKeyint } = keyintFor(info.fps);
  const clip = {
    id: pick.id,
    src: info.path,
    srcName: info.name,
    scene: pick.scene,
    tags: pick.tags,
    src: info.path,
    size: info.size,
    width: info.width, height: info.height, codedRotation: info.rotation,
    displayWidth: info.rotation % 180 === 0 ? info.width : info.height,
    displayHeight: info.rotation % 180 === 0 ? info.height : info.width,
    pixFmt: info.pixFmt, codec: info.codec, is10bit: false, isHDR: false,
    prim: info.prim, trc: info.trc, matrix: info.matrix,
    avgFps: info.fps, containerDuration: info.duration,
    vBitrate: info.vBitrate, audio: info.audio,
    dateRaw: info.dateRaw, keysDate: info.keysDate, qtDate: info.qtDate,
    rotation: info.rotation,
    timeline: {
      count: tl.count, timescale: tl.timescale, span: tl.span,
      uniqueDeltas: tl.uniqueDeltas, topDeltas: tl.topDeltas,
      vfr: tl.uniqueDeltas > 3,
    },
    segment: {
      startIdx, startPts, frames, endPts: segPts[segPts.length - 1],
      duration: norm[norm.length - 1],
      avgFps: frames / Math.max(norm[norm.length - 1], 1e-9),
      requestedStart: pick.start, requestedDur: pick.dur,
      keyint, minKeyint,
    },
  };
  manifest.clips.push(clip);
  await fs.writeFile(path.join(ROOT, 'media', `pts-${pick.id}.json`), JSON.stringify(norm), 'utf8');

  const st = await fs.stat(path.join(ROOT, 'media', `pts-${pick.id}.json`));
  console.log(`${pick.id} ${info.name}  ${clip.displayWidth}x${clip.displayHeight} rot=${info.rotation} `
    + `seg ${fmt(startPts, 6)}s +${frames}f ${fmt(clip.segment.duration, 4)}s avg=${fmt(clip.segment.avgFps, 2)}fps `
    + `keyint=${keyint}/${minKeyint} srcRatio100=${((info.vBitrate * 1e6 * clip.segment.duration / 8))} bytes`);
  void st;
}

await fs.writeFile(path.join(ROOT, 'media', 'manifest.json'), JSON.stringify(manifest, null, 2), 'utf8');
console.log('\n已冻结 media/manifest.json');
