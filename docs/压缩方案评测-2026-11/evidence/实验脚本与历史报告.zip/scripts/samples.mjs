/**
 * 从 MP4 样本表读取每条视频样本的字节数，用于精确计算“原片同区间”的字节量，
 * 避免用平均码率估算占比。
 */
import fs from 'node:fs/promises';

function boxes(buffer, start = 0, end = buffer.length) {
  const result = [];
  for (let offset = start; offset + 8 <= end;) {
    let size = buffer.readUInt32BE(offset), header = 8;
    if (size === 1) { size = Number(buffer.readBigUInt64BE(offset + 8)); header = 16; }
    if (size === 0) size = end - offset;
    if (size < header || offset + size > end) throw new Error('MP4 容器长度不完整');
    result.push({ type: buffer.toString('ascii', offset + 4, offset + 8), start: offset + header, end: offset + size });
    offset += size;
  }
  return result;
}

async function readMoov(file) {
  const handle = await fs.open(file, 'r');
  try {
    const { size: fileSize } = await handle.stat();
    const header = Buffer.alloc(16);
    for (let offset = 0; offset + 8 <= fileSize;) {
      const read = await handle.read(header, 0, Math.min(16, fileSize - offset), offset);
      if (read.bytesRead < 8) return null;
      let size = header.readUInt32BE(0), prefix = 8;
      if (size === 1) { size = Number(header.readBigUInt64BE(8)); prefix = 16; }
      if (size === 0) size = fileSize - offset;
      if (size < prefix || offset + size > fileSize) return null;
      if (header.toString('ascii', 4, 8) === 'moov') {
        if (size - prefix > 128 * 1024 * 1024) return null;
        const data = Buffer.alloc(size - prefix);
        let filled = 0;
        while (filled < data.length) {
          const part = await handle.read(data, filled, data.length - filled, offset + prefix + filled);
          if (!part.bytesRead) return null;
          filled += part.bytesRead;
        }
        return data;
      }
      offset += size;
    }
    return null;
  } finally { await handle.close(); }
}

/** 返回第一条视频轨的样本字节数组；分片 MP4 返回 null。 */
export async function readSampleSizes(file) {
  const buffer = await readMoov(file);
  if (!buffer) return null;
  for (const trak of boxes(buffer).filter((b) => b.type === 'trak')) {
    const mdia = boxes(buffer, trak.start, trak.end).find((b) => b.type === 'mdia');
    if (!mdia) continue;
    const entries = boxes(buffer, mdia.start, mdia.end);
    const hdlr = entries.find((b) => b.type === 'hdlr');
    if (!hdlr || buffer.toString('ascii', hdlr.start + 8, hdlr.start + 12) !== 'vide') continue;
    const minf = entries.find((b) => b.type === 'minf');
    if (!minf) continue;
    const stbl = boxes(buffer, minf.start, minf.end).find((b) => b.type === 'stbl');
    if (!stbl) continue;
    const stsz = boxes(buffer, stbl.start, stbl.end).find((b) => b.type === 'stsz');
    if (!stsz) return null;
    const fixed = buffer.readUInt32BE(stsz.start + 4);
    const count = buffer.readUInt32BE(stsz.start + 8);
    if (!count) return null;
    const sizes = new Array(count);
    if (fixed) sizes.fill(fixed);
    else for (let i = 0; i < count; i++) sizes[i] = buffer.readUInt32BE(stsz.start + 12 + i * 4);
    return sizes;
  }
  return null;
}
