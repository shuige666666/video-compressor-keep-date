/**
 * 串行执行全部编码：A/B/C/D 为固定 CRF，E/F 以 A/C 的实际视频码率为目标校准。
 * 编码全程单任务，不并发；每次的耗时、大小、帧核对写入 logs/。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { ROOT, LOGS, SCRATCH, ensureDirs } from './lib.mjs';

const only = process.argv.slice(2).filter((a) => /^C\d$/.test(a));
const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const clips = manifest.clips.filter((c) => !only.length || only.includes(c.id));
await ensureDirs();
await fs.mkdir(path.join(SCRATCH, 'calib'), { recursive: true });

const histPath = path.join(LOGS, 'calibration.json');
let history = [];
try { history = JSON.parse(await fs.readFile(histPath, 'utf8')); } catch { history = []; }

function encode(clipId, variant, extra = []) {
  return new Promise((resolve, reject) => {
    const args = [path.join(ROOT, 'scripts', 'encode.mjs'), '--clip', clipId, '--variant', variant, ...extra];
    const cp = spawn(process.execPath, args, { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
    let err = '';
    cp.stdout.on('data', (d) => process.stdout.write(d));
    cp.stderr.on('data', (d) => { err += d.toString(); process.stderr.write(d); });
    cp.on('close', (code) => (code === 0 ? resolve() : reject(new Error(`${clipId}/${variant} 失败: ${err.slice(-400)}`))));
  });
}

for (const clip of clips) {
  console.log(`\n===== ${clip.id} ${clip.srcName} (${clip.segment.frames}f) =====`);
  for (const v of ['A', 'B', 'C', 'D']) await encode(clip.id, v);

  const recA = JSON.parse(await fs.readFile(path.join(LOGS, `${clip.id}-x265_medium_crf22.json`), 'utf8'));
  const recC = JSON.parse(await fs.readFile(path.join(LOGS, `${clip.id}-x265_medium_crf24.json`), 'utf8'));

  for (const [variant, ref, labelKey] of [
    ['E', recA, 'nvenc_p7_eq_medium22'],
    ['F', recC, 'nvenc_p7_eq_medium24'],
  ]) {
    const target = ref.videoKbps;
    console.log(`\n--- ${clip.id}/${variant} 目标 ${target}kbps（来自 ${ref.label} ${recA.outBytes} bytes）`);
    await encode(clip.id, variant, ['--bitrateK', String(target)]);
    let rec = JSON.parse(await fs.readFile(path.join(LOGS, `${clip.id}-${labelKey}.json`), 'utf8'));
    history.push({ clip: clip.id, variant, attempt: 1, target, actual: rec.videoKbps, ratio: rec.videoKbps / target, bytes: rec.outBytes, frames: rec.frameCheck.outFrames, timelineOk: rec.frameCheck.ok, at: new Date().toISOString() });

    if (Math.abs(rec.videoKbps / target - 1) > 0.05) {
      // 只修正一次：按实际/目标比例反向调整，避免反复试编码
      const adj = Math.round(target * (target / rec.videoKbps));
      console.log(`  偏差 ${((rec.videoKbps / target - 1) * 100).toFixed(1)}% → 重新校准为 ${adj}kbps`);
      await encode(clip.id, variant, ['--bitrateK', String(adj)]);
      rec = JSON.parse(await fs.readFile(path.join(LOGS, `${clip.id}-${labelKey}.json`), 'utf8'));
      history.push({ clip: clip.id, variant, attempt: 2, target: adj, actual: rec.videoKbps, ratio: rec.videoKbps / adj, bytes: rec.outBytes, frames: rec.frameCheck.outFrames, timelineOk: rec.frameCheck.ok, at: new Date().toISOString() });
    }
    await fs.writeFile(histPath, JSON.stringify(history, null, 2), 'utf8');
  }
}
console.log('\n全部编码完成');
