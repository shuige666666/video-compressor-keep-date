/**
 * 生成人工复审截图：每个时刻从原片与全部编码版本抽取同一显示帧，全分辨率 PNG。
 * 一次解码抽取该版本的全部时刻，避免逐帧重复 seek；色彩转换链对所有版本完全一致。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, run, ensureDirs } from './lib.mjs';

const argv = process.argv.slice(2);
const clipFilter = argv.filter((a) => /^C\d$/.test(a));

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const framesPlan = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'frames.json'), 'utf8'));
await ensureDirs();

const VF = (expr) => `select='${expr}',scale=in_range=tv:out_range=pc:in_color_matrix=bt709:out_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=rgb24`;
const pad = (n, w = 3) => String(n).padStart(w, '0');

for (const clip of manifest.clips.filter((c) => !clipFilter.length || clipFilter.includes(c.id))) {
  const plan = framesPlan[clip.id];
  if (!plan?.frames?.length) { console.log(`${clip.id} 未定义截图帧，跳过`); continue; }

  const clipDir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
  const encDir = path.join(clipDir, '编码结果');
  const tmp = path.join(ROOT, 'scratch', 'shots', clip.id);
  await fs.mkdir(tmp, { recursive: true });
  await fs.mkdir(clipDir, { recursive: true });

  const idxs = plan.frames.map((f) => f.idx).sort((a, b) => a - b);
  const expr = idxs.map((i) => `eq(n\\,${i})`).join('+');

  const versions = [{ label: '原片', src: clip.src, isSource: true }];
  for (const f of (await fs.readdir(encDir)).filter((x) => x.endsWith('.mp4')).sort()) {
    versions.push({ label: path.basename(f, '.mp4'), src: path.join(encDir, f), isSource: false });
  }

  for (const v of versions) {
    const outDir = path.join(tmp, v.label);
    await fs.rm(outDir, { recursive: true, force: true });
    await fs.mkdir(outDir, { recursive: true });
    const args = ['-y', '-hide_banner', '-loglevel', 'error'];
    if (v.isSource) args.push('-ss', Math.max(0, clip.segment.startPts - 0.0005).toFixed(6));
    args.push('-i', v.src, '-vf', VF(expr), '-fps_mode:v', 'passthrough',
      '-frames:v', String(idxs.length), '-f', 'image2', path.join(outDir, '%02d.png'));
    const r = await run(FF, args);
    if (r.code !== 0) { console.error(`${clip.id}/${v.label} 抽帧失败 ${r.stderr.slice(-300)}`); continue; }
    const got = (await fs.readdir(outDir)).filter((x) => x.endsWith('.png')).sort();
    if (got.length !== idxs.length) console.error(`${clip.id}/${v.label} 抽到 ${got.length}/${idxs.length} 帧`);
    for (let i = 0; i < got.length; i++) {
      const idx = idxs[i];
      const fno = plan.frames.find((f) => f.idx === idx).fno;
      const dst = path.join(clipDir, `${fno}_n${pad(idx, 6)}_${v.label}_full.png`);
      await fs.rename(path.join(outDir, got[i]), dst);
    }
    console.log(`${clip.id} ${v.label} → ${got.length} 张`);
  }

  // 局部裁剪：坐标基于原分辨率，所有版本同坐标同尺寸，1:1 像素
  for (const f of plan.frames) {
    for (const roi of f.roi || []) {
      for (const v of versions) {
        const srcPng = path.join(clipDir, `${f.fno}_n${pad(f.idx, 6)}_${v.label}_full.png`);
        const dstPng = path.join(clipDir, `${f.fno}_n${pad(f.idx, 6)}_${v.label}_${roi.name}.png`);
        const r = await run(FF, ['-y', '-hide_banner', '-loglevel', 'error', '-i', srcPng,
          '-vf', `crop=${roi.w}:${roi.h}:${roi.x}:${roi.y}`, '-frames:v', '1', dstPng]);
        if (r.code !== 0) console.error(`裁剪失败 ${dstPng}`);
      }
    }
  }
  await fs.rm(tmp, { recursive: true, force: true });
}
console.log('\n截图完成');
