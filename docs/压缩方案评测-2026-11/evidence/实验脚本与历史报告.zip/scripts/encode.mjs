/**
 * 执行单次编码：完全串行，记录命令、耗时、大小、逐帧时间轴核对、拍摄时间写回。
 * 用法：node scripts/encode.mjs --clip C1 --variant A
 *       node scripts/encode.mjs --clip C1 --variant E --bitrateK 4200 --tag cal1
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, buildArgs, run, probe, timelineStats, restoreDate, comparePts, ensureDirs, fmt } from './lib.mjs';
import { VARIANTS } from './variants.mjs';

const argv = process.argv.slice(2);
const opt = (name, dflt = null) => {
  const i = argv.indexOf('--' + name);
  return i >= 0 ? argv[i + 1] : dflt;
};
const has = (name) => argv.includes('--' + name);

const clipId = opt('clip');
const variantKey = opt('variant');
const framesOverride = opt('frames') ? Number(opt('frames')) : null;
const bitrateK = opt('bitrateK') ? Number(opt('bitrateK')) : null;
const tag = opt('tag') || '';
const labelOverride = opt('label') || '';
const outDirOverride = opt('outDir');

await ensureDirs();
const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const clip = manifest.clips.find((c) => c.id === clipId);
if (!clip) throw new Error('未知 clip ' + clipId);
const variant = { ...VARIANTS[variantKey] };
if (!variant) throw new Error('未知 variant ' + variantKey);
if (bitrateK) variant.bitrateK = bitrateK;

const clipDir = outDirOverride || path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
const encDir = path.join(clipDir, '编码结果');
await fs.mkdir(encDir, { recursive: true });

const label = labelOverride || (tag ? `${variant.label}_${tag}` : variant.label);
const dst = path.join(encDir, `${label}.mp4`);

const seg = {
  start: Math.max(0, clip.segment.startPts - 0.0005), // 0.5ms 余量：-ss 以微秒取整，避免首帧被丢
  frames: framesOverride || clip.segment.frames,
};
const info = {
  prim: clip.prim, trc: clip.trc, matrix: clip.matrix,
  is10bit: clip.is10bit, isHDR: clip.isHDR, audio: clip.audio, fps: clip.avgFps,
};
const args = buildArgs(info, clip.src, dst, variant, seg);

console.log(`[${clipId}/${label}] ${dst}`);
console.log('  ' + [FF, ...args].map((a) => (/[\s]/.test(a) ? `"${a}"` : a)).join(' '));

if (has('dry')) process.exit(0);

const startedAt = new Date().toISOString();
const r = await run(FF, args, {
  onStdout: (chunk) => {
    // 只保留关键进度，避免日志膨胀
    if (chunk.includes('speed=') || chunk.includes('progress=end')) process.stdout.write('');
  },
});
const encodeMs = r.ms;

// ffmpeg -progress 输出里取 speed / fps / bitrate
let reported = {};
for (const line of r.stdout.split(/\r?\n/)) {
  const [k, v] = line.split('=');
  if (!k) continue;
  if (['speed', 'fps', 'bitrate', 'total_size', 'out_time_ms'].includes(k.trim())) reported[k.trim()] = v?.trim();
}

if (r.code !== 0) {
  console.error(`  编码失败 code=${r.code}\n${r.stderr.slice(-2000)}`);
  await fs.writeFile(path.join(ROOT, 'logs', `${clipId}-${label}.error.txt`), r.stderr, 'utf8');
  process.exit(1);
}

const postStart = Date.now();
const outInfo = await probe(dst);
const outTl = await timelineStats(dst);
const expectedAll = JSON.parse(await fs.readFile(path.join(ROOT, 'media', `pts-${clip.id}.json`), 'utf8'));
const expectedPts = expectedAll.slice(0, Math.min(expectedAll.length, outTl.count));
const cmp = comparePts(expectedPts, outTl.pts);
const tolerance = Math.max(1 / 90000, 1 / outTl.timescale) * 1.5 + 1e-6;

const dateRes = await restoreDate({ dateRaw: clip.dateRaw }, dst);
const afterDate = await probe(dst);
const totalMs = encodeMs + (Date.now() - postStart);

const encDur = outInfo.duration || clip.segment.duration;
const segmentBytes = clip.vBitrate * 1000 / 8 * encDur;
// 音频为直拷，按已知码率折算后得到视频码率
const audioBytes = clip.audio ? (clip.audio.bitrate || 0) * 1000 / 8 * encDur : 0;
const videoBytes = Math.max(0, outInfo.size - audioBytes);
const videoKbps = videoBytes * 8 / encDur / 1000;

const record = {
  clip: clip.id, srcName: clip.srcName, variant: variant.key, label,
  encoder: variant.encoder, preset: variant.preset, crf: variant.crf ?? null,
  targetBitrateK: variant.bitrateK ?? null, targetFrom: variant.targetFrom ?? null,
  startPtsRequested: seg.start, framesRequested: seg.frames,
  startedAt, encodeMs, totalMs,
  ffmpegSpeed: reported.speed || '', ffmpegFps: reported.fps || '', ffmpegBitrate: reported.bitrate || '',
  outBytes: outInfo.size,
  videoKbps: Math.round(videoKbps),
  audioKbps: outInfo.audio?.bitrate || 0,
  ratioOfSourceSegment: outInfo.size / segmentBytes,
  srcSegmentBytes: Math.round(segmentBytes),
  out: { width: outInfo.width, height: outInfo.height, rotation: outInfo.rotation, pixFmt: outInfo.pixFmt, prim: outInfo.prim, trc: outInfo.trc, matrix: outInfo.matrix, fps: outInfo.fps, duration: outInfo.duration, codec: outInfo.codec },
  frameCheck: {
    srcFrames: clip.segment.frames, outFrames: outTl.count,
    ok: outTl.count === clip.segment.frames && cmp.ok && cmp.maxErr <= tolerance,
    countOk: outTl.count === clip.segment.frames,
    maxPtsErr: cmp.maxErr, atFrame: cmp.at, tolerance,
    outTimescale: outTl.timescale, outUniqueDeltas: outTl.uniqueDeltas,
  },
  dateRestore: { ...dateRes, verify: { qtCreate: afterDate.qtCreate, trackCreate: afterDate.qtTrackCreate, track2Create: afterDate.qtTrack2Create, mediaCreate: afterDate.qtMediaCreate, keysDate: afterDate.keysDate, fileCreate: afterDate.fileCreate } },
  argv: args, ffmpegPath: FF, version: outInfo.encoderTag,
};
await fs.writeFile(path.join(ROOT, 'logs', `${clipId}-${label}.json`), JSON.stringify(record, null, 2), 'utf8');

console.log(`  编码 ${fmt(encodeMs / 1000, 2)}s (${reported.speed || '?'}x, ${reported.fps || '?'}fps) 总 ${fmt(totalMs / 1000, 2)}s`);
console.log(`  大小 ${(outInfo.size / 1e6).toFixed(2)}MB 视频 ${Math.round(videoKbps)}kbps 占原片段 ${(outInfo.size / segmentBytes * 100).toFixed(1)}%`);
console.log(`  输出 ${outInfo.width}x${outInfo.height} rot=${outInfo.rotation} ${outInfo.pixFmt} ${outInfo.prim}/${outInfo.trc}/${outInfo.matrix} dur=${fmt(outInfo.duration, 3)}s`);
console.log(`  帧核对 ${record.frameCheck.ok ? 'OK' : 'FAIL'} src=${clip.segment.frames} out=${outTl.count} maxErr=${((cmp.maxErr ?? -1) * 1000).toFixed(3)}ms tol=${(tolerance * 1000).toFixed(3)}ms at=${cmp.at}`);
console.log(`  时间写回 ${dateRes.ok ? 'OK ' + dateRes.stamp : 'FAIL ' + dateRes.error} | CreateDate=${afterDate.qtCreate} Track1=${afterDate.qtTrackCreate} Keys=${afterDate.keysDate}`);
