/**
 * 复核片段：用一段完全没有参与调参的素材，验证最终推荐的两档配置。
 * 与主实验相同的参数、相同的核对与评分口径，但不参与任何表格的横向比较。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, buildArgs, run, probe, timelineStats, restoreDate, comparePts, ensureDirs, readVideoTimeline, keyintFor, fmt } from './lib.mjs';

const SRC = 'E:\\VideoEdit\\每天拍几秒企划\\10.25-\\VID_20261031_204856.mp4';
const TAG = 'H1';
const DUR = 10;
const OUT = path.join(ROOT, 'holdout');
await ensureDirs();
await fs.mkdir(path.join(OUT, '编码结果'), { recursive: true });

const info = await probe(SRC);
const tl = await timelineStats(SRC);
const pts = tl.pts;
const startIdx = pts.findIndex((p) => p >= 1.5);
const startPts = pts[startIdx];
let frames = 0;
while (startIdx + frames < pts.length && pts[startIdx + frames] < startPts + DUR - 1e-9) frames++;
const segPts = pts.slice(startIdx, startIdx + frames).map((p) => p - startPts);

const { keyint, minKeyint } = keyintFor(info.fps);
const clipInfo = {
  prim: info.prim, trc: info.trc, matrix: info.matrix,
  is10bit: false, isHDR: false, audio: info.audio, fps: info.fps,
};
console.log(`${info.name} ${info.width}x${info.height} rot=${info.rotation} ${fmt(info.fps)}fps`);
console.log(`选区：第 ${startIdx} 帧起 ${frames} 帧（${fmt(startPts, 4)}s 起，${fmt(segPts[segPts.length - 1], 4)}s）`);

const VARIANTS = [
  { label: 'x265_medium_crf22', encoder: 'x265', preset: 'medium', crf: 22 },
  { label: 'x265_fast_crf21', encoder: 'x265', preset: 'fast', crf: 21 },
  { label: 'nvenc_p7_eq_medium22', encoder: 'nvenc', preset: 'p7' },
];

const rows = [];
let mediumKbps = 0;
for (const v of VARIANTS) {
  const dst = path.join(OUT, '编码结果', `${v.label}.mp4`);
  // NVENC 必须先拿到 medium 的实际码率作为目标，否则 -rc vbr 会用默认低码率
  const variant = v.encoder === 'nvenc' ? { ...v, bitrateK: Math.round(mediumKbps) } : v;
  const args = buildArgs(clipInfo, SRC, dst, variant, { start: Math.max(0, startPts - 0.0005), frames });
  const r = await run(FF, args);
  if (r.code !== 0) { console.error(v.label, r.stderr.slice(-400)); continue; }
  const oi = await probe(dst);
  const otl = await timelineStats(dst);
  const cmp = comparePts(segPts, otl.pts);
  const dur = oi.duration || segPts[segPts.length - 1];
  const audioBytes = info.audio ? (info.audio.bitrate || 0) * 1000 / 8 * dur : 0;
  const kbps = (oi.size - audioBytes) * 8 / dur / 1000;
  if (v.label === 'x265_medium_crf22') mediumKbps = kbps;
  await restoreDate({ dateRaw: info.dateRaw }, dst);
  rows.push({ label: v.label, bytes: oi.size, kbps: Math.round(kbps), encodeMs: r.ms, frames: otl.count, maxErr: cmp.maxErr, timelineOk: otl.count === frames && cmp.ok });
  console.log(`${v.label.padEnd(24)} ${(oi.size / 1e6).toFixed(2)}MB ${Math.round(kbps)}kbps ${fmt(r.ms / 1000, 1)}s 帧=${otl.count}/${frames} 时间戳偏差=${(cmp.maxErr * 1000).toFixed(3)}ms`);
}

// NVENC 按 medium 实际码率补一次校准
const med = rows.find((x) => x.label === 'x265_medium_crf22');
const nv = rows.find((x) => x.label === 'nvenc_p7_eq_medium22');
if (med && nv && Math.abs(nv.kbps / med.kbps - 1) > 0.05) {
  const adj = Math.round(med.kbps * (med.kbps / nv.kbps));
  console.log(`NVENC 偏差 ${((nv.kbps / med.kbps - 1) * 100).toFixed(1)}% → 按 ${adj}kbps 重编`);
  const dst = path.join(OUT, '编码结果', 'nvenc_p7_eq_medium22.mp4');
  const v = { ...VARIANTS[2], bitrateK: adj };
  const r = await run(FF, buildArgs(clipInfo, SRC, dst, v, { start: Math.max(0, startPts - 0.0005), frames }));
  const oi = await probe(dst);
  const otl = await timelineStats(dst);
  const dur = oi.duration || segPts[segPts.length - 1];
  const audioBytes = info.audio ? (info.audio.bitrate || 0) * 1000 / 8 * dur : 0;
  const kbps = (oi.size - audioBytes) * 8 / dur / 1000;
  await restoreDate({ dateRaw: info.dateRaw }, dst);
  Object.assign(nv, { bytes: oi.size, kbps: Math.round(kbps), encodeMs: r.ms, frames: otl.count, targetKbps: adj });
  console.log(`  校准后 ${(oi.size / 1e6).toFixed(2)}MB ${Math.round(kbps)}kbps`);
}

// 逐帧评分：全分辨率 PSNR/SSIM + VMAF 4K 模型
const GRAPH = (p, s, v) => [
  '[0:v]settb=1/1000,setpts=N,format=yuv420p,split=3[r1][r2][r3]',
  '[1:v]settb=1/1000,setpts=N,format=yuv420p,split=3[d1][d2][d3]',
  `[d1][r1]psnr=stats_file=${p}:shortest=1[o1]`,
  `[d2][r2]ssim=stats_file=${s}:shortest=1[o2]`,
  `[d3][r3]libvmaf=model=version=vmaf_4k_v0.6.1:log_fmt=json:log_path=${v}:n_threads=8:shortest=1[o3]`,
].join(';');

const avg = (a) => a.reduce((x, y) => x + y, 0) / Math.max(1, a.length);
for (const row of rows) {
  const wd = 'holdout/tmp';
  await fs.mkdir(path.join(ROOT, wd), { recursive: true });
  const p = `${wd}/${row.label}-psnr.log`, s = `${wd}/${row.label}-ssim.log`, v = `${wd}/${row.label}-vmaf.json`;
  const args = ['-y', '-hide_banner', '-loglevel', 'error', '-ss', Math.max(0, startPts - 0.0005).toFixed(6), '-i', SRC,
    '-i', path.join(OUT, '编码结果', `${row.label}.mp4`), '-lavfi', GRAPH(p, s, v),
    '-map', '[o1]', '-frames:v', String(frames), '-f', 'null', '-',
    '-map', '[o2]', '-frames:v', String(frames), '-f', 'null', '-',
    '-map', '[o3]', '-frames:v', String(frames), '-f', 'null', '-'];
  const r = await run(FF, args, { cwd: ROOT });
  if (r.code !== 0) { console.error('评分失败', row.label, r.stderr.slice(-300)); continue; }
  const psnr = [...(await fs.readFile(path.join(ROOT, p), 'utf8')).matchAll(/psnr_avg:([\d.]+)/g)].map((m) => +m[1]);
  const ssim = [...(await fs.readFile(path.join(ROOT, s), 'utf8')).matchAll(/All:([\d.]+)/g)].map((m) => +m[1]);
  const vmaf = JSON.parse(await fs.readFile(path.join(ROOT, v), 'utf8')).frames.map((x) => x.metrics.vmaf);
  Object.assign(row, { psnr: avg(psnr), ssim: avg(ssim), vmaf: avg(vmaf) });
  console.log(`${row.label.padEnd(24)} PSNR ${fmt(row.psnr)} SSIM ${row.ssim.toFixed(5)} VMAF ${fmt(row.vmaf)}`);
}

const summary = {
  source: SRC, startIdx, startPts, frames, duration: segPts[segPts.length - 1],
  sourceBytes: (await fs.stat(SRC)).size, rows,
  generatedAt: new Date().toISOString(),
};
await fs.writeFile(path.join(ROOT, 'report', 'holdout.json'), JSON.stringify(summary, null, 2), 'utf8');
console.log('\n已写 report/holdout.json');
