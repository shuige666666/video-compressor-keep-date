/** 合并手机两种色彩解释、验证截图，并独立出具报告；不重写原实验汇总。 */
import fs from 'node:fs/promises';import path from 'node:path';
import {ROOT} from './lib.mjs';import {readDisplaySampleSizes} from './phone-sample-sizes.mjs';
const read=async p=>JSON.parse(await fs.readFile(path.join(ROOT,p),'utf8'));
const m=await read('media/manifest.json'),plans=await read('media/frames.json'),base=await read('report/data.json');
const rows=[],checks=[];
const f=(x,n=2)=>x.toFixed(n);
const out=['# 手机相册补充评估','','本报告补充原来的 x265 / NVENC 实验，保留既有结果。手机六个完整视频的帧数和相对逐帧 PTS 均与原片一致。评分沿用原实验冻结区间、原分辨率、全帧、VMAF 4K v0.6.1 模型。','','## 色彩解释必须区分','','手机标记为 bt470bg/bt470bg/smpte170m，原片为 BT.709。仅凭标签无法断言像素是否转换，因此同时提供两种口径：','','- **直接 YUV / 按原片709**：不改 YUV 数值，与原片直接评分；截图按 BT.709 矩阵转 RGB。','- **按手机601标记**：将手机 BT.601 矩阵转换到 BT.709 比较域后评分；截图按 BT.601 矩阵转 RGB。这里只归一化矩阵，不额外映射 primaries/transfer。','','两组指标不能互相混用，也不能选得分更高的一组宣布编码器胜出。色彩转换可改变指标，尤其 VMAF 不是专门的色彩准确度指标；标签与像素的最终解释仍需结合人工同帧观看。不要把 BT.601 本身称为“4K 视频的错误格式”。','','## 手机全片与同一实验选区','','|片段|手机完整大小 MB|占完整原片|选区视频轨占比|选区码率 Mbps|直接YUV PSNR / SSIM / VMAF|按601 PSNR / SSIM / VMAF|','|---|---:|---:|---:|---:|---|---|'];
let pictures=0;
for(const c of m.clips){
 const a=await read('metrics/phone/'+c.id+'.json'),b=await read('metrics/phone/'+c.id+'-709.json');
 const src=await readDisplaySampleSizes(c.src),phone=await readDisplaySampleSizes(a.phone);
 const sum=t=>t.sizes.slice(c.segment.startIdx,c.segment.startIdx+c.segment.frames).reduce((x,y)=>x+y,0);
 a.sourceVideoPayloadBytes=sum(src);a.phoneVideoPayloadBytes=sum(phone);a.segmentVideoRatio=sum(phone)/sum(src);a.videoMbps=sum(phone)*8/c.segment.duration/1e6;a.payloadOrder='display-order';
 const r={...a,directYuv:{psnr:a.rawYuvPsnr,ssim:b.ssim,vmaf:b.vmaf},tagMatrix:{psnr:a.psnr,ssim:a.ssim,vmaf:a.vmaf},colorConclusion:'two explicit hypotheses; not evidence by labels alone'};
 delete r.perFrame;rows.push(r);
 out.push(`|${c.id}|${f(a.phoneBytes/1e6)}|${f(a.fullRatio*100,1)}%|${f(a.segmentVideoRatio*100,1)}%|${f(a.videoMbps)}|${f(a.rawYuvPsnr.avg)} / ${f(b.ssim.avg,5)} / ${f(b.vmaf.avg)}|${f(a.psnr.avg)} / ${f(a.ssim.avg,5)} / ${f(a.vmaf.avg)}|`);
 const dir=path.join(ROOT,'results',c.id+'_'+path.basename(c.srcName,'.mp4'));
 for(const frame of plans[c.id].frames){
  for(const variant of ['手机相册压缩','手机相册压缩_按原片709']){
   const stem=`${frame.fno}_n${String(frame.idx).padStart(6,'0')}_${variant}`;
   const expect=[{suffix:'full',w:c.displayWidth,h:c.displayHeight},...(frame.roi||[]).map(x=>({suffix:x.name,w:x.w,h:x.h}))];
   for(const e of expect){const png=await fs.readFile(path.join(dir,stem+'_'+e.suffix+'.png'));if(png.readUInt32BE(16)!==e.w||png.readUInt32BE(20)!==e.h)throw Error('截图尺寸不符 '+stem);pictures++;}
  }
 }
 const local=['# '+c.id+' 手机相册复审说明','','同一 F 编号及 n 帧号对应原实验同一画面，保持已有裁剪坐标。新增两种独立 PNG：','','- `手机相册压缩_full/roi01.png`：按手机标记 BT.601 解读。','- `手机相册压缩_按原片709_full/roi01.png`：按原片 BT.709 解读，用于检查标签与像素是否一致。','','每种解释各5张全图，加上原计划中的局部裁剪，不拼接、不放大。先比较两种手机解释与原片的颜色，再比较纹理与运动；不要只选得分较高的解释。','','完整手机文件：['+path.basename(a.phone)+']('+a.phone.replaceAll('\\','/')+')','','全片为原片 '+f(a.fullRatio*100,1)+'%；同选区视频轨为原选区 '+f(a.segmentVideoRatio*100,1)+'%。PC 目录中的片段约10秒，手机文件是完整视频，不直接比较整个文件字节量。','','|解释|PSNR|SSIM|VMAF / p5|','|---|---:|---:|---:|',`|按原片709|${f(a.rawYuvPsnr.avg)}|${f(b.ssim.avg,5)}|${f(b.vmaf.avg)} / ${f(b.vmaf.p5)}|`,`|按手机601|${f(a.psnr.avg)}|${f(a.ssim.avg,5)}|${f(a.vmaf.avg)} / ${f(a.vmaf.p5)}|`,'','源全片 '+a.sourceFrames+' 帧，手机 '+a.phoneFrames+' 帧，相对逐帧 PTS 最大误差 '+a.maxPtsError*1000+' ms。手机时间字段变成压缩时间。手机耗时为用户报告“大多10秒内”，未逐片计时。'];
 await fs.writeFile(path.join(dir,'手机相册复审说明.md'),local.join('\n'),'utf8');
 checks.push({clip:c.id,frames:a.frames,vmafFrames:b.frames,screenshotMoments:plans[c.id].frames.length});
}
out.push('','## PC 同选区参考（实际视频轨体积）','','下表仅陈列现有配置；没有追加调码率重编码，因此同列画质差不能直接解释为同体积编码效率。','','|片段|策略|选区视频 MB|PSNR|SSIM|VMAF|编码秒|','|---|---|---:|---:|---:|---:|');
for(const c of m.clips){const dir=path.join(ROOT,'results',c.id+'_'+path.basename(c.srcName,'.mp4'),'编码结果');for(const r of base.filter(x=>x.clip===c.id&&!x.label.includes('slow'))){const t=await readDisplaySampleSizes(path.join(dir,r.label+'.mp4'));const bytes=t.sizes.reduce((x,y)=>x+y,0);out.push(`|${c.id}|${r.label}|${f(bytes/1e6)}|${r.psnrAvg}|${r.ssimAvg}|${r.vmafAvg}|${r.encodeSec}|`);}}
out.push('','## 速度与正确性','','用户报告手机相册对完整视频大多在10秒或以内完成；这不是逐片实测，也与PC约10秒选区、不同设备的计时口径不同，不计算精确加速倍数。所有手机与原片的全片帧数及逐帧相对时间戳完全一致。未额外宣称音频逐包无损或完整音画同步测试完成。六个手机文件的拍摄时间字段均变成压缩时间。','','## 人工复审与复现','','results 每段目录共新增两组5帧全图及对应局部图，共 '+pictures+' 张 PNG。原片及已有 PC 截图不变，各视频有手机相册复审说明.md。','','运行顺序：node scripts/phone-compare.mjs；node scripts/phone-709.mjs；node scripts/phone-finish.mjs。前两脚本支持已有评分恢复；最终以本报告和 phone-data.json 的 dual color fields 为准。帧截断放在滤镜前，以冻结 N 帧为准；旧试跑日志预取的末尾多一帧不纳入指标。');
out.push('','## 如何理解结果','','手机并非所有场景都表现差：C1 夜景的两种口径 VMAF 都很高，C3 舞台、C5 餐桌按标记口径也较高。但手机与 PC 未统一码率，不能把更高分直接当作更高压缩效率。C2 漫展与 C6 密集人群的手机 VMAF 约89，比同实验中的 PC 多数档位低，手机同时给了更低的码率；这两段应优先人工检查。','','C6 可以重点比较手机版与现有 medium CRF26：后者原报告 VMAF 93.77，手机按标记为 '+rows.find(r=>r.clip==='C6').vmaf.avg.toFixed(2)+'，但大小仍有差额，不属于严格同体积实验。','','色彩指标的反例：C4 直接YUV PSNR '+rows.find(r=>r.clip==='C4').rawYuvPsnr.avg.toFixed(2)+' dB，而矩阵归一化后 '+rows.find(r=>r.clip==='C4').psnr.avg.toFixed(2)+' dB；VMAF 的变化方向却不一定相同。不要按更高 VMAF 选择色彩解释。C1 对矩阵的反应与 C4 不同，因此没有统一宣称六段均只改标签或均转换了像素。','','建议先看 C2 F01 衣物发丝、C6 F02 人头手臂，再看 C5 F01 瓶盖字和 F05 锅壁。原片始终保留作参照，先确认颜色再判断细节；截图不能体现所有运动闪烁。');
await fs.writeFile(path.join(ROOT,'report/手机相册补充评估.md'),out.join('\n'),'utf8');
await fs.writeFile(path.join(ROOT,'report/phone-data.json'),JSON.stringify(rows,null,2),'utf8');
const h=['clip','fullRatio','segmentVideoRatio','videoMbps','directPsnr','directSsim','directVmaf','tagPsnr','tagSsim','tagVmaf'];
await fs.writeFile(path.join(ROOT,'report/手机相册汇总.csv'),'\ufeff'+[h.join(','),...rows.map(a=>[a.clip,a.fullRatio,a.segmentVideoRatio,a.videoMbps,a.directYuv.psnr.avg,a.directYuv.ssim.avg,a.directYuv.vmaf.avg,a.tagMatrix.psnr.avg,a.tagMatrix.ssim.avg,a.tagMatrix.vmaf.avg].join(','))].join('\n'),'utf8');
await fs.writeFile(path.join(ROOT,'report/phone-verification.json'),JSON.stringify({pictures,checks},null,2),'utf8');
console.log(JSON.stringify({pictures,rows:rows.map(a=>({clip:a.clip,ratio:a.fullRatio,segmentRatio:a.segmentVideoRatio,rawPSNR:a.rawYuvPsnr.avg,tagPSNR:a.psnr.avg,rawVmaf:a.directYuv.vmaf.avg,tagVmaf:a.tagMatrix.vmaf.avg}))},null,2));
