/**
 * NVENC 兼容性矩阵验证：在 VFR 素材（C4）上检查不同配置的帧数与逐帧时间戳。
 * 不写正式结果，只用于确定正式测试采用哪套 NVENC 参数。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, run, timelineStats, comparePts, ensureDirs, fmt, SCRATCH } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const clip = manifest.clips.find((c) => c.id === (process.argv[2] || 'C4'));
const frames = Number(process.argv[3] || 180);
const expected = JSON.parse(await fs.readFile(path.join(ROOT, 'media', `pts-${clip.id}.json`), 'utf8')).slice(0, frames);
await ensureDirs();
const dir = path.join(SCRATCH, 'compat');
await fs.mkdir(dir, { recursive: true });

const base = ['-y', '-hide_banner', '-loglevel', 'error', '-progress', 'pipe:1', '-nostats'];
if (clip.segment.startPts > 0) base.push('-ss', Math.max(0, clip.segment.startPts - 0.0005).toFixed(6));
base.push('-i', clip.src, '-frames:v', String(frames), '-map', '0:v:0', '-an');
base.push('-fps_mode:v:0', 'passthrough');
base.push('-pix_fmt', 'yuv420p', '-profile:v', 'main');
base.push('-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709');

const CONFIGS = [
  { name: 'nvenc_p7_bf3_tb-1', opts: ['-enc_time_base:v:0', '-1', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '3', '-b_ref_mode', 'middle'] },
  { name: 'nvenc_p7_bf0_tb-1', opts: ['-enc_time_base:v:0', '-1', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '0'] },
  { name: 'nvenc_p7_bf3_tb90000', opts: ['-enc_time_base:v:0', '1/90000', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '3', '-b_ref_mode', 'middle'] },
  { name: 'nvenc_p7_bf0_tb90000', opts: ['-enc_time_base:v:0', '1/90000', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '0'] },
  { name: 'nvenc_p7_bf3_brefdisabled', opts: ['-enc_time_base:v:0', '-1', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '3', '-b_ref_mode', 'disabled'] },
  { name: 'nvenc_p7_bf2_tb-1', opts: ['-enc_time_base:v:0', '-1', '-c:v', 'hevc_nvenc', '-preset', 'p7', '-tune', 'hq', '-rc', 'vbr', '-b:v', '8000k', '-multipass', 'fullres', '-rc-lookahead', '32', '-spatial-aq', '1', '-temporal-aq', '1', '-bf', '2', '-b_ref_mode', 'middle'] },
  { name: 'x265_medium_ref', opts: ['-enc_time_base:v:0', '-1', '-c:v', 'libx265', '-preset', 'medium', '-crf', '22', '-x265-params', 'keyint=30:min-keyint=15:log-level=error'] },
];

const rows = [];
for (const cfg of CONFIGS) {
  const dst = path.join(dir, `${cfg.name}.mp4`);
  const r = await run(FF, [...base, ...cfg.opts, '-tag:v', 'hvc1', dst]);
  if (r.code !== 0) {
    console.log(`${cfg.name.padEnd(30)} FAILED ${r.stderr.slice(-160).replace(/\s+/g, ' ')}`);
    rows.push({ name: cfg.name, error: r.stderr.slice(-300) });
    continue;
  }
  const t = await timelineStats(dst);
  const cmp = comparePts(expected, t.pts);
  const tol = 1 / 90000 * 1.5 + 1e-6;
  const ok = t.count === frames && cmp.ok && cmp.maxErr <= tol;
  console.log(`${cfg.name.padEnd(30)} frames=${String(t.count).padStart(4)} maxErr=${((cmp.maxErr ?? 0) * 1000).toFixed(3).padStart(8)}ms  deltas=${t.uniqueDeltas}  ${ok ? 'OK' : 'TIMELINE-BROKEN'}`);
  rows.push({ name: cfg.name, frames: t.count, maxErrMs: (cmp.maxErr ?? null) * 1000, uniqueDeltas: t.uniqueDeltas, ok, encodeMs: r.ms });
}
await fs.writeFile(path.join(dir, `compat-${clip.id}.json`), JSON.stringify(rows, null, 2), 'utf8');
console.log(`\n已写 scratch/compat/compat-${clip.id}.json`);
