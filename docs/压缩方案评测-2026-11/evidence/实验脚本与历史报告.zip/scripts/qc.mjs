/**
 * 独立核对：输出色彩/范围是否与源一致、音轨是否原样拷贝且起点对齐。
 * 与时间轴核对相互独立，不依赖编码器自报信息。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { ROOT, FF, run, METRICS, ensureDirs, fmt } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
await ensureDirs();

function parseStats(text) {
  const rows = [];
  let cur = {};
  for (const line of text.split(/\r?\n/)) {
    const m = /^frame:(\d+)\s+pts:\S+\s+pts_time:\S+$/.exec(line.trim());
    if (m) { if (Object.keys(cur).length) rows.push(cur); cur = { frame: +m[1] }; continue; }
    const kv = /^lavfi\.signalstats\.([A-Z0-9]+)=([\d.-]+)$/.exec(line.trim());
    if (kv) cur[kv[1]] = +kv[2];
  }
  if (Object.keys(cur).length) rows.push(cur);
  return rows.filter((r) => r.YAVG != null);
}

const mean = (a) => a.reduce((x, y) => x + y, 0) / Math.max(1, a.length);

async function signalStats(file, ss, frames) {
  const wd = path.join(METRICS, 'tmp');
  await fs.mkdir(wd, { recursive: true });
  // 滤镜内路径用相对路径，避免盘符冒号与中文路径破坏参数解析
  const rel = `metrics/tmp/sig-${crypto.createHash('md5').update(file + String(ss)).digest('hex').slice(0, 8)}.txt`;
  const out = path.join(ROOT, rel);
  const args = ['-y', '-hide_banner', '-loglevel', 'error', '-ss', ss.toFixed(6), '-i', file,
    '-frames:v', String(frames), '-vf', `signalstats,metadata=print:file=${rel}`, '-f', 'null', '-'];
  const r = await run(FF, args, { cwd: ROOT });
  if (r.code !== 0) { console.error('signalstats 失败', r.stderr.slice(-200)); return null; }
  const rows = parseStats(await fs.readFile(out, 'utf8'));
  if (!rows.length) return null;
  return {
    n: rows.length,
    YAVG: mean(rows.map((x) => x.YAVG)), UAVG: mean(rows.map((x) => x.UAVG)), VAVG: mean(rows.map((x) => x.VAVG)),
    YMIN: Math.min(...rows.map((x) => x.YMIN)), YMAX: Math.max(...rows.map((x) => x.YMAX)),
    SATAVG: mean(rows.map((x) => x.SATAVG ?? 0)),
  };
}

/** 取片段首/中/尾三个 12 帧窗口，避免整段解码；只用于发现系统性色彩偏移。 */
async function windowStats(file, baseSs, dur, n) {
  const spots = [baseSs + 0.2, baseSs + dur / 2, baseSs + Math.max(0.2, dur - 0.6)];
  const parts = [];
  for (const ss of spots) {
    const s = await signalStats(file, ss, 12);
    if (s) parts.push(s);
  }
  void n;
  if (!parts.length) return null;
  return {
    n: parts.reduce((a, b) => a + b.n, 0),
    YAVG: mean(parts.map((p) => p.YAVG)), UAVG: mean(parts.map((p) => p.UAVG)), VAVG: mean(parts.map((p) => p.VAVG)),
    YMIN: Math.min(...parts.map((p) => p.YMIN)), YMAX: Math.max(...parts.map((p) => p.YMAX)),
    SATAVG: mean(parts.map((p) => p.SATAVG)),
  };
}

async function audioMd5(file, ss, seconds) {
  const args = ['-hide_banner', '-loglevel', 'error'];
  if (ss != null) args.push('-ss', ss.toFixed(6));
  args.push('-i', file, '-t', String(seconds), '-map', '0:a:0', '-ac', '2', '-ar', '48000', '-c:a', 'pcm_s16le', '-f', 'md5', '-');
  const r = await run(FF, args);
  return r.code === 0 ? r.stdout.trim() : null;
}

const results = [];
for (const clip of manifest.clips) {
  const clipDir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
  const encDir = path.join(clipDir, '编码结果');
  const N = clip.segment.frames;
  const segStart = Math.max(0, clip.segment.startPts - 0.0005);
  const srcStats = await windowStats(clip.src, segStart, clip.segment.duration, N);
  const srcAudio = await audioMd5(clip.src, segStart, 3);

  const rows = [];
  for (const f of (await fs.readdir(encDir)).filter((x) => x.endsWith('.mp4')).sort()) {
    const label = path.basename(f, '.mp4');
    const enc = path.join(encDir, f);
    const st = await windowStats(enc, 0, clip.segment.duration, N);
    const au = await audioMd5(enc, null, 3);
    const dY = st && srcStats ? st.YAVG - srcStats.YAVG : null;
    rows.push({
      clip: clip.id, label,
      srcYAVG: srcStats?.YAVG, outYAVG: st?.YAVG, dYAVG: dY,
      srcYMIN: srcStats?.YMIN, outYMIN: st?.YMIN, srcYMAX: srcStats?.YMAX, outYMAX: st?.YMAX,
      dU: st && srcStats ? st.UAVG - srcStats.UAVG : null,
      dV: st && srcStats ? st.VAVG - srcStats.VAVG : null,
      audioMd5Match: au && srcAudio ? au === srcAudio : null,
      audioMd5Out: au, audioMd5Src: srcAudio,
    });
    console.log(`${clip.id} ${label.padEnd(28)} ΔY=${fmt(dY ?? 0, 3)} ΔU=${fmt(st && srcStats ? st.UAVG - srcStats.UAVG : 0, 3)} ΔV=${fmt(st && srcStats ? st.VAVG - srcStats.VAVG : 0, 3)} Y[${st?.YMIN},${st?.YMAX}] 音轨一致=${au === srcAudio}`);
  }
  results.push({ clip: clip.id, srcStats, rows });
}
await fs.writeFile(path.join(ROOT, 'metrics', 'qc-color-audio.json'), JSON.stringify(results, null, 2), 'utf8');
console.log('\n已写 metrics/qc-color-audio.json');
