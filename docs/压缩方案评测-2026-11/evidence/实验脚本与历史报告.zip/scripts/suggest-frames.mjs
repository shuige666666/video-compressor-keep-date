/**
 * 建议复审时刻：均匀分布 + 各版本 VMAF 最低的局部窗口，并生成仅供内部勘察的小图。
 * 最终选择写入 media/frames.json，需人工确认内容代表性。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, METRICS, SCRATCH, run } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const clipId = process.argv[2];
const clip = manifest.clips.find((c) => c.id === clipId);
const encDir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`, '编码结果');
const labels = (await fs.readdir(encDir)).filter((f) => f.endsWith('.mp4')).map((f) => path.basename(f, '.mp4'));
const N = clip.segment.frames;

// 逐帧取各版本最低 VMAF，作为“该时刻最容易暴露差异”的指标
const byFrame = new Map();
for (const label of labels) {
  let met;
  try { met = JSON.parse(await fs.readFile(path.join(METRICS, `${clip.id}-${label}.json`), 'utf8')); } catch { continue; }
  for (const f of met.perFrame) {
    const cur = byFrame.get(f.n) || { n: f.n, vmaf: 100, psnr: 99 };
    cur.vmaf = Math.min(cur.vmaf, f.vmaf ?? 100);
    cur.psnr = Math.min(cur.psnr, f.psnr ?? 99);
    byFrame.set(f.n, cur);
  }
}
const arr = [...byFrame.values()].sort((a, b) => a.n - b.n);
// 平滑窗口（0.4s）后取局部最低，避免抓到单帧抖动
const W = Math.max(3, Math.round(clip.segment.avgFps * 0.4));
const smooth = arr.map((_, i) => {
  const s = Math.max(0, i - W), e = Math.min(arr.length - 1, i + W);
  let sum = 0, cnt = 0;
  for (let j = s; j <= e; j++) { sum += arr[j].vmaf; cnt++; }
  return sum / cnt;
});
const cands = [];
for (let i = 0; i < arr.length; i++) cands.push({ i, n: arr[i].n, score: smooth[i] });
cands.sort((a, b) => a.score - b.score);
const picked = [];
for (const c of cands) {
  if (picked.length >= 4) break;
  if (picked.some((p) => Math.abs(p.n - c.n) < clip.segment.avgFps * 1.2)) continue;
  picked.push(c);
}

const uniform = [0.08, 0.3, 0.52, 0.74, 0.92].map((p) => Math.round((N - 1) * p));
console.log(`\n${clip.id} ${clip.srcName} N=${N} fps≈${clip.segment.avgFps.toFixed(2)}`);
console.log('  均匀候选帧:', uniform.join(', '));
console.log('  指标最低窗口:', picked.map((p) => `n=${p.n}(vmaf ${p.score.toFixed(2)})`).join('  '));
const vmafs = arr.map((a) => a.vmaf).sort((a, b) => a - b);
console.log(`  VMAF 分布: min ${vmafs[0].toFixed(2)} p5 ${vmafs[Math.floor(vmafs.length * 0.05)].toFixed(2)} median ${vmafs[Math.floor(vmafs.length / 2)].toFixed(2)}`);

// 内部勘察小图（不进入交付目录）
const all = [...new Set([...uniform, ...picked.map((p) => p.n)])].sort((a, b) => a - b);
const outDir = path.join(SCRATCH, 'cand', clip.id);
await fs.mkdir(outDir, { recursive: true });
const expr = all.map((i) => `eq(n\\,${i})`).join('+');
const r = await run(FF, ['-y', '-hide_banner', '-loglevel', 'error', '-ss', Math.max(0, clip.segment.startPts - 0.0005).toFixed(6),
  '-i', clip.src, '-vf', `select='${expr}',scale=420:-2`, '-fps_mode:v', 'passthrough',
  '-frames:v', String(all.length), '-f', 'image2', '-start_number', '1', path.join(outDir, 'c%02d.png')]);
console.log('  预览:', r.code === 0 ? outDir : r.stderr.slice(-200), all.map((n, i) => `c${String(i + 1).padStart(2, '0')}=n${n}`).join(' '));
