/** 手机相册补充评估：只读输入，按冻结区间和帧号评分、截图，不改动原实验结果。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import {ROOT,FF,probe,run,readVideoTimeline} from './lib.mjs';
const manifest=JSON.parse(await fs.readFile(path.join(ROOT,'media/manifest.json'),'utf8'));
const plans=JSON.parse(await fs.readFile(path.join(ROOT,'media/frames.json'),'utf8'));
const base=JSON.parse(await fs.readFile(path.join(ROOT,'report/data.json'),'utf8'));
const md=path.join(ROOT,'metrics/phone'); await fs.mkdir(md,{recursive:true});
const check=async(r,stage)=>{if(r.code!==0)throw Error(stage+': '+r.stderr.slice(-1400));return r;};
const stats=a=>{const s=[...a].sort((a,b)=>a-b);return {avg:a.reduce((x,y)=>x+y,0)/a.length,min:s[0],p5:s[Math.floor((s.length-1)*.05)]};};
const psnr=t=>[...t.matchAll(/psnr_avg:([\d.]+)/g)].map(x=>+x[1]);
const results=[];
// 同一来源一次性抽取所有复审帧；每个版本延续已有的 RGB 截图转换口径。
async function evaluate(c){
 const file=path.join('E:/VideoEdit/每天拍几秒企划/手机相册压缩',c.srcName.replace(/\.mp4$/i,'_COMPRESSED.mp4'));
 const info=await probe(file), original=await readVideoTimeline(c.src), phone=await readVideoTimeline(file);
 if(original.count!==phone.count)throw Error(c.id+' 帧数不等，需重新确定映射');
 const maxErr=Math.max(...Array.from(original.pts,(p,i)=>Math.abs(p-phone.pts[i])));
 if(maxErr>2/Math.min(original.timescale,phone.timescale))throw Error(c.id+' 时间戳不对应');
 const rel=`metrics/phone/${c.id}`;
 const ss=Math.max(0,c.segment.startPts-.0005).toFixed(6), N=c.segment.frames;
 const json=path.join(md,c.id+'.json');
 let rec;
 try{rec=JSON.parse(await fs.readFile(json,'utf8'));}catch{}
 if(!rec){
  console.log(c.id+' 开始全帧评分 '+N+'帧');
  // 601→709 是比较域归一化，不能据此断言手机写错标记。原始 YUV 误差仅作诊断。
  const g=[
   `[0:v]trim=end_frame=${N},settb=1/1000,setpts=N,format=yuv420p,split=4[r0][r1][r2][r3]`,
   `[1:v]trim=end_frame=${N},settb=1/1000,setpts=N,format=yuv420p,split=2[d0][dc]`,
   '[dc]scale=in_color_matrix=bt601:out_color_matrix=bt709:in_range=tv:out_range=tv,format=yuv420p,split=3[d1][d2][d3]',
   `[d0][r0]psnr=stats_file=${rel}-raw-psnr.log:shortest=1[o0]`,
   `[d1][r1]psnr=stats_file=${rel}-psnr.log:shortest=1[o1]`,
   `[d2][r2]ssim=stats_file=${rel}-ssim.log:shortest=1[o2]`,
   `[d3][r3]libvmaf=model=version=vmaf_4k_v0.6.1:log_fmt=json:log_path=${rel}-vmaf.json:n_threads=4:shortest=1[o3]`
  ].join(';');
  const args=['-hide_banner','-loglevel','error','-ss',ss,'-i',c.src,'-ss',ss,'-i',file,'-filter_complex',g];
  for(let i=0;i<4;i++)args.push('-map',`[o${i}]`,'-frames:v',String(N),'-fps_mode','passthrough','-f','null','-');
  // 已完整写出的评分日志只取冻结区间内前 N 帧，避免中断后重复计算。
  let complete=false;
  try { complete=JSON.parse(await fs.readFile(path.join(ROOT,rel+'-vmaf.json'),'utf8')).frames.length>=N; } catch {}
  const r=complete?{ms:null}:await check(await run(FF,args,{cwd:ROOT}),c.id+'评分');
  const rp=psnr(await fs.readFile(path.join(ROOT,rel+'-raw-psnr.log'),'utf8')).slice(0,N);
  const p=psnr(await fs.readFile(path.join(ROOT,rel+'-psnr.log'),'utf8')).slice(0,N);
  const s=[...(await fs.readFile(path.join(ROOT,rel+'-ssim.log'),'utf8')).matchAll(/All:([\d.]+)/g)].map(x=>+x[1]).slice(0,N);
  const v=JSON.parse(await fs.readFile(path.join(ROOT,rel+'-vmaf.json'),'utf8')).frames.map(x=>x.metrics.vmaf).slice(0,N);
  if([rp.length,p.length,s.length,v.length].some(x=>x!==N))throw Error(c.id+'评分帧数不完整 '+[rp.length,p.length,s.length,v.length]);
  const {readSampleSizes}=await import('./samples.mjs');
  const srcSizes=await readSampleSizes(c.src), phoneSizes=await readSampleSizes(file);
  const sum=(a,start,n)=>a.slice(start,start+n).reduce((x,y)=>x+y,0);
  const srcPayload=sum(srcSizes,c.segment.startIdx,N),payload=sum(phoneSizes,c.segment.startIdx,N);
  rec={clip:c.id,src:c.src,phone:file,sourceBytes:(await fs.stat(c.src)).size,phoneBytes:info.size,fullRatio:info.size/(await fs.stat(c.src)).size,info,sourceFrames:original.count,phoneFrames:phone.count,maxPtsError:maxErr,segment:c.segment,frames:N,sourceVideoPayloadBytes:srcPayload,phoneVideoPayloadBytes:payload,segmentVideoRatio:payload/srcPayload,videoMbps:payload*8/c.segment.duration/1e6,colorPolicy:'phone BT.601 matrix -> BT.709 matrix, limited range; no primaries/transfer remapping; same native 8-bit resolution',rawYuvPsnr:stats(rp),psnr:stats(p),ssim:stats(s),vmaf:stats(v),model:'vmaf_4k_v0.6.1',subsample:1,scoreMs:r.ms,phoneEncodeTiming:'用户报告：六个完整视频大多在10秒内完成；无逐片测量，不计入本机速度倍数',perFrame:p.map((x,i)=>({n:i,psnr:x,ssim:s[i],vmaf:v[i]}))};
  await fs.writeFile(json,JSON.stringify(rec,null,2),'utf8');
  console.log(c.id+' 评分完成 '+JSON.stringify({PSNR:rec.psnr.avg,VMAF:rec.vmaf.avg,rawPSNR:rec.rawYuvPsnr.avg}));
 }
 // 恢复运行时也重算区间字节，按显示顺序映射 B 帧，避免误用解码顺序索引。
 const {readDisplaySampleSizes}=await import('./phone-sample-sizes.mjs');
 const srcSamples=await readDisplaySampleSizes(c.src), phoneSamples=await readDisplaySampleSizes(file);
 const payloadSum=a=>a.slice(c.segment.startIdx,c.segment.startIdx+N).reduce((x,y)=>x+y,0);
 rec.sourceVideoPayloadBytes=payloadSum(srcSamples.sizes); rec.phoneVideoPayloadBytes=payloadSum(phoneSamples.sizes);
 rec.segmentVideoRatio=rec.phoneVideoPayloadBytes/rec.sourceVideoPayloadBytes; rec.videoMbps=rec.phoneVideoPayloadBytes*8/c.segment.duration/1e6;
 rec.payloadOrder='display-order via stts+ctts';
 await fs.writeFile(json,JSON.stringify(rec,null,2),'utf8');
 const dir=path.join(ROOT,'results',c.id+'_'+path.basename(c.srcName,'.mp4'));
 const plan=[...plans[c.id].frames].sort((a,b)=>a.idx-b.idx);
 const names=plan.map(f=>`${f.fno}_n${String(f.idx).padStart(6,'0')}_手机相册压缩_full.png`);
 const allExist=await Promise.all(names.map(n=>fs.stat(path.join(dir,n)).then(()=>true).catch(()=>false)));
 if(!allExist.every(Boolean)){
  const expr=plan.map(f=>`eq(n\\,${f.idx})`).join('+');
  const tmp=path.join(md,c.id+'-shots'); await fs.mkdir(tmp,{recursive:true});
  const args=['-y','-hide_banner','-loglevel','error','-ss',ss,'-i',file,'-vf',`select='${expr}',scale=in_range=tv:out_range=pc:in_color_matrix=bt601:out_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=rgb24`,'-fps_mode','passthrough','-frames:v',String(plan.length),path.join(tmp,'%02d.png')];
  await check(await run(FF,args),c.id+'截图');
  for(let i=0;i<plan.length;i++)await fs.copyFile(path.join(tmp,String(i+1).padStart(2,'0')+'.png'),path.join(dir,names[i]));
 }
 for(let i=0;i<plan.length;i++)for(const roi of plan[i].roi||[]){
  const dest=path.join(dir,names[i].replace('_full.png','_'+roi.name+'.png'));
  if(await fs.stat(dest).then(()=>true).catch(()=>false))continue;
  await check(await run(FF,['-y','-hide_banner','-loglevel','error','-i',path.join(dir,names[i]),'-vf',`crop=${roi.w}:${roi.h}:${roi.x}:${roi.y}`,'-frames:v','1',dest]),c.id+'局部截图');
 }
 const note=path.join(dir,'手机相册复审说明.md');
 await fs.writeFile(note,`# ${c.id} 手机相册补充对比\n\n输入：[手机相册完整视频](${file.replaceAll('\\','/')})\n\n截图直接放在本目录，文件名以“手机相册压缩”标识；沿用原复审说明中的五个 F 编号、相同帧号和裁剪坐标，没有拼接。截图采用手机实际标注的 BT.601 矩阵解读；原有原片/x265/NVENC 图片不变。\n\n整个原视频 ${original.count} 帧，手机版 ${phone.count} 帧，相对时间戳最大差 ${maxErr*1000} ms。\n\n同一选区统一矩阵后 PSNR ${rec.psnr.avg.toFixed(2)} dB / SSIM ${rec.ssim.avg.toFixed(5)} / VMAF ${rec.vmaf.avg.toFixed(2)}，VMAF p5 ${rec.vmaf.p5.toFixed(2)}。\n\n全片文件为原片 ${(rec.fullRatio*100).toFixed(1)}%；选区视频轨为原选区视频轨 ${(rec.segmentVideoRatio*100).toFixed(1)}%。不能把全片手机大小与 PC 的十秒选区文件大小直接比较。\n\n用户报告手机压缩大多不超过10秒，未逐片计时。原片与手机片的拍摄时间字段见补充报告。\n`,'utf8');
 console.log(c.id+' 截图完成'); results.push(rec);
}
// 两组评分并行，避免同时启动六个 4K 评分占满内存；无压缩测速任务。
const queue=[...manifest.clips];await Promise.all([0,1].map(async()=>{while(queue.length)await evaluate(queue.shift());}));
results.sort((a,b)=>a.clip.localeCompare(b.clip));
await fs.writeFile(path.join(ROOT,'report/phone-data.json'),JSON.stringify(results,null,2),'utf8');
const lines=['# 手机相册压缩补充评估','','六个完整手机版本与对应原片逐帧时间轴一致。评测仍使用原实验冻结的帧区间；六段均以原生分辨率、逐帧 PSNR/SSIM/VMAF 4K 模型评分。未重编码手机文件。','','手机耗时：用户报告完整视频大多在10秒或10秒以内完成，未逐片实测，不能据此计算与 PC 十秒选区的精确速度倍数。','','## 色彩与评分口径','','手机标记 bt470bg/bt470bg/smpte170m，原片 BT.709。对手机 YUV 做 BT.601→BT.709 矩阵归一化后与原片评分；没有把其全部标签简单当成错误，也没有把色度矩阵变换产生的误差当成纯压缩损失。未进行 primaries/transfer 的额外映射。原始 YUV PSNR 作为诊断保留。截图按各自矩阵转 RGB，与已有图片保持一致的范围与输出口径。此口径仍不代表所有严格色彩管理播放器的结果。','','## 手机结果','','|片段|全片大小 MB|全片占原片|同区间视频轨占比|PSNR 归一化 / 原始YUV|SSIM|VMAF / p5|medium22 / fast22 / NVENC匹配22 VMAF|','|---|---:|---:|---:|---:|---:|---:|---|'];
for(const r of results){const lookup=l=>base.find(x=>x.clip===r.clip&&x.label===l);lines.push(`|${r.clip}|${(r.phoneBytes/1e6).toFixed(2)}|${(r.fullRatio*100).toFixed(1)}%|${(r.segmentVideoRatio*100).toFixed(1)}%|${r.psnr.avg.toFixed(2)} / ${r.rawYuvPsnr.avg.toFixed(2)}|${r.ssim.avg.toFixed(5)}|${r.vmaf.avg.toFixed(2)} / ${r.vmaf.p5.toFixed(2)}|${['x265_medium_crf22','x265_fast_crf22','nvenc_p7_eq_medium22'].map(l=>lookup(l).vmafAvg).join(' / ')}|`);}
lines.push('','PC 各版本与手机版本并未对齐体积，此表用于定位各自的实际结果，不能据此直接排名同码率编码效率。原实验 CSV 的占原片分母为原选区视频轨字节，分子是 PC 整个文件，含音频和封装；这里同时给出全片文件比例及严格的视频轨对视频轨比例。','','## 人工复审','','results 下每段新增 5 张全图与现有计划相同数量的局部图，文件名为 Fxx_nxxxxxx_手机相册压缩_full/roi01.png。直接切换同一 F 编号、相同 full 或 roi 的图片。保留全部已有图片。','','## 元数据','','六个手机版拍摄时间字段均改为本次压缩时间，不保留原拍摄时间；不改动提供的文件。六段逐帧时间戳与原片一致，但这不能替代音频完整同步核对，本次未额外声称音频逐包完全一致。','','## 可复现','','运行 node scripts/phone-compare.mjs；评分在 metrics/phone/，报告数据在 report/phone-data.json。评分支持已完成片段恢复，图片来源始终是完整手机文件对应选区，未复制 PC 文件冒充手机版本。');
await fs.writeFile(path.join(ROOT,'report/手机相册补充评估.md'),lines.join('\n'),'utf8');
const header='clip,fullSizeBytes,fullRatio,segmentVideoRatio,psnr,ssim,vmaf,vmafP5,sourceFrames,phoneFrames,maxPtsError';
await fs.writeFile(path.join(ROOT,'report/手机相册汇总.csv'),'\ufeff'+[header,...results.map(r=>[r.clip,r.phoneBytes,r.fullRatio,r.segmentVideoRatio,r.psnr.avg,r.ssim.avg,r.vmaf.avg,r.vmaf.p5,r.sourceFrames,r.phoneFrames,r.maxPtsError].join(','))].join('\n'),'utf8');
console.log('手机评估全部完成');
