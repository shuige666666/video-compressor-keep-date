/** 同时保留原始709解释与手机601标签解释，避免把色彩假设冒充压缩质量结论。 */
import fs from 'node:fs/promises';import path from 'node:path';
import {ROOT,FF,run,probe} from './lib.mjs';
const m=JSON.parse(await fs.readFile(path.join(ROOT,'media/manifest.json'),'utf8'));
const plans=JSON.parse(await fs.readFile(path.join(ROOT,'media/frames.json'),'utf8'));
const stat=a=>{const b=[...a].sort((x,y)=>x-y);return {avg:a.reduce((x,y)=>x+y,0)/a.length,min:b[0],p5:b[Math.floor(.05*(b.length-1))]};};
const ok=(r)=>{if(r.code!==0)throw Error(r.stderr.slice(-1000));};
for(const c of m.clips){
 const src=path.join('E:/VideoEdit/每天拍几秒企划/手机相册压缩',c.srcName.replace('.mp4','_COMPRESSED.mp4')),N=c.segment.frames;
 const file=path.join(ROOT,'metrics/phone',c.id+'-709.json'), rel=`metrics/phone/${c.id}-709`, ss=Math.max(0,c.segment.startPts-.0005).toFixed(6);
 let rec;try{rec=JSON.parse(await fs.readFile(file,'utf8'));}catch{}
 if(!rec){
  console.log(c.id+' 开始原始YUV/709口径评分');
  const g=[`[0:v]trim=end_frame=${N},settb=1/1000,setpts=N,format=yuv420p,split=2[r1][r2]`,`[1:v]trim=end_frame=${N},settb=1/1000,setpts=N,format=yuv420p,split=2[d1][d2]`,`[d1][r1]ssim=stats_file=${rel}-ssim.log:shortest=1[o1]`,`[d2][r2]libvmaf=model=version=vmaf_4k_v0.6.1:log_fmt=json:log_path=${rel}-vmaf.json:n_threads=4:shortest=1[o2]`].join(';');
  const args=['-hide_banner','-loglevel','error','-threads','4','-ss',ss,'-i',c.src,'-threads','4','-ss',ss,'-i',src,'-filter_complex_threads','2','-filter_complex',g];
  for(const i of [1,2])args.push('-map',`[o${i}]`,'-frames:v',String(N),'-fps_mode','passthrough','-f','null','-');
  ok(await run(FF,args,{cwd:ROOT}));
  const s=[...(await fs.readFile(path.join(ROOT,rel+'-ssim.log'),'utf8')).matchAll(/All:([\d.]+)/g)].map(x=>+x[1]);
  const v=JSON.parse(await fs.readFile(path.join(ROOT,rel+'-vmaf.json'),'utf8')).frames.map(x=>x.metrics.vmaf);
  if(s.length!==N||v.length!==N)throw Error(c.id+'评分数量不完整');
  rec={clip:c.id,frames:N,policy:'unchanged YUV / interpret as source BT.709; diagnostic alternative, not proof of wrong tags',ssim:stat(s),vmaf:stat(v),perFrame:v.map((x,i)=>({n:i,ssim:s[i],vmaf:x}))};
  await fs.writeFile(file,JSON.stringify(rec,null,2),'utf8');console.log(c.id+' 原始YUV VMAF '+rec.vmaf.avg.toFixed(2));
 }
 const dir=path.join(ROOT,'results',c.id+'_'+path.basename(c.srcName,'.mp4')),p=[...plans[c.id].frames].sort((a,b)=>a.idx-b.idx);
 const names=p.map(f=>`${f.fno}_n${String(f.idx).padStart(6,'0')}_手机相册压缩_按原片709_full.png`);
 if(!(await Promise.all(names.map(n=>fs.stat(path.join(dir,n)).then(()=>true).catch(()=>false)))).every(Boolean)){
  const tmp=path.join(ROOT,'metrics/phone',c.id+'-709-shots');await fs.mkdir(tmp,{recursive:true});
  const expr=p.map(f=>`eq(n\\,${f.idx})`).join('+');
  ok(await run(FF,['-y','-hide_banner','-loglevel','error','-threads','4','-ss',ss,'-i',src,'-vf',`select='${expr}',scale=in_range=tv:out_range=pc:in_color_matrix=bt709:out_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=rgb24`,'-fps_mode','passthrough','-frames:v',String(p.length),path.join(tmp,'%02d.png')]));
  for(let i=0;i<p.length;i++)await fs.copyFile(path.join(tmp,String(i+1).padStart(2,'0')+'.png'),path.join(dir,names[i]));
 }
 for(let i=0;i<p.length;i++)for(const roi of p[i].roi||[]){const dst=path.join(dir,names[i].replace('_full.png','_'+roi.name+'.png'));if(await fs.stat(dst).then(()=>true).catch(()=>false))continue;ok(await run(FF,['-y','-hide_banner','-loglevel','error','-i',path.join(dir,names[i]),'-vf',`crop=${roi.w}:${roi.h}:${roi.x}:${roi.y}`,'-frames:v','1',dst]));}
 console.log(c.id+' 两种色彩解释已备齐709组');
}
