/** 探测候选素材：输出完整参数、逐帧时间轴统计，供冻结素材清单使用。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, probe, timelineStats, fmt } from './lib.mjs';

const BASE1 = 'E:\\VideoEdit\\每天拍几秒企划\\10.25-';
const BASE2 = 'E:\\VideoEdit\\每天拍几秒企划\\9.35-10.24';

export const CANDIDATES = [
  { id: 'C1', file: path.join(BASE1, 'VID_20261031_202656.mp4') },
  { id: 'C2', file: path.join(BASE1, 'VID_20261108_204248.mp4') },
  { id: 'C3', file: path.join(BASE1, 'VID_20261108_211624.mp4') },
  { id: 'C4', file: path.join(BASE1, 'VID_20261031_204355.mp4') },
  { id: 'C5', file: path.join(BASE2, 'VID_20261003_111508.mp4') },
  { id: 'C6', file: path.join(BASE1, 'VID_20261031_205503.mp4') },
];

const out = [];
for (const c of CANDIDATES) {
  const p = await probe(c.file);
  const t = await timelineStats(c.file);
  out.push({ id: c.id, ...p, timeline: t ? { ...t, pts: undefined } : null });
  console.log(`\n=== ${c.id} ${p.name}`);
  console.log(`  ${p.width}x${p.height} ${p.pixFmt} ${p.codec} ${fmt(p.fps, 3)}fps (tbr ${p.tbr}, tbn ${p.tbn}) range=${p.range}`);
  console.log(`  color prim=${p.prim}(${p.rawPrim}) trc=${p.trc}(${p.rawTrc}) matrix=${p.matrix}(${p.rawMatrix}) rotation=${p.rotation}`);
  console.log(`  duration=${fmt(p.duration, 3)}s size=${p.size} vbr=${p.vBitrate}kbps audio=${p.audio?.codec}/${p.audio?.bitrate}kbps/${p.audio?.sampleRate}Hz/${p.audio?.channels}`);
  console.log(`  date=${p.dateRaw} | qtCreate=${p.qtCreate}`);
  if (t) console.log(`  frames=${t.count} timescale=${t.timescale} span=${fmt(t.span, 4)}s uniqueDelta=${t.uniqueDeltas} top=${JSON.stringify(t.topDeltas.slice(0, 4))}`);
}

await fs.mkdir(path.join(ROOT, 'media'), { recursive: true });
await fs.writeFile(path.join(ROOT, 'media', 'probe-raw.json'), JSON.stringify(out, null, 2), 'utf8');
console.log('\n已写 media/probe-raw.json');
