/** 生成每段视频的 复审说明.md：参数、指标、截图帧号与局部坐标。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, METRICS } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const rows = JSON.parse(await fs.readFile(path.join(ROOT, 'report', 'data.json'), 'utf8'));
const plan = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'frames.json'), 'utf8'));

const f3 = (x) => (x == null ? '—' : Number(x).toFixed(2));
const ORDER = ['x265_medium_crf22','x265_fast_crf22','x265_medium_crf24','x265_fast_crf24','nvenc_p7_eq_medium22','nvenc_p7_eq_medium24','nvenc_p5_eq_medium22','nvenc_p7_higher_bitrate','x265_fast_crf21','x265_slow_crf22','x265_medium_crf26'];
const orderOf = (l) => (ORDER.includes(l) ? ORDER.indexOf(l) : 99);
const isVfr = (c) => { const t = c.timeline.topDeltas; if (!t || t.length < 2) return false; const r = t[1].delta / t[0].delta; return (r > 1.4 || r < 0.714) && t[1].n / c.timeline.count > 0.05; };

for (const clip of manifest.clips) {
  const mine = rows.filter((r) => r.clip === clip.id);
  if (!mine.length) continue;
  const p = plan[clip.id];
  const lines = [];
  lines.push(`# ${clip.id} 复审说明 — ${clip.srcName}`);
  lines.push('');
  lines.push('## 素材与选区');
  lines.push('');
  lines.push(`- 源文件：\`${clip.src}\``);
  lines.push(`- 容器尺寸 ${clip.width}×${clip.height}，旋转 ${clip.rotation}°，实际显示 ${clip.displayWidth}×${clip.displayHeight}；${clip.pixFmt}，HEVC Main，色彩 ${clip.prim}/${clip.trc}/${clip.matrix}（tv range）`);
  lines.push(`- 逐帧时间轴：${clip.timeline.count} 帧，时基 ${clip.timeline.timescale}，时长 ${clip.timeline.span.toFixed(4)}s，帧间隔 ${clip.timeline.uniqueDeltas} 种${isVfr(clip) ? '（可变帧率）' : '（间隔抖动属时间基舍入）'}`);
  lines.push(`- 选区：第 ${clip.segment.startIdx} 帧起 ${clip.segment.frames} 帧（${clip.segment.startPts.toFixed(4)}s 起，跨度 ${clip.segment.duration.toFixed(4)}s，平均 ${clip.segment.avgFps.toFixed(2)}fps）`);
  lines.push(`- 场景：${clip.scene}`);
  lines.push(`- 拍摄时间（原片）：${clip.dateRaw}`);
  lines.push('');
  lines.push('## 编码结果');
  lines.push('');
  lines.push('| 版本 | 编码参数 | 目标码率 | 实际视频码率 | 文件大小 | 占原片同区间 | 编码耗时 | 速度(帧/秒) | 帧数核对 | 时间戳最大偏差 |');
  lines.push('|---|---|---|---|---|---|---|---|---|---|');
  for (const r of mine.sort((a, b) => orderOf(a.label) - orderOf(b.label))) {
    const param = r.encoder === 'nvenc'
      ? `NVENC ${r.preset}${r.targetKbps ? `，按 ${r.targetKbps} kbps 校准` : ''}`
      : `x265 ${r.preset}${r.crf !== '' ? ' CRF' + r.crf : ''}`;
    lines.push(`| ${r.label} | ${param} | ${r.targetKbps ? r.targetKbps + ' kbps' : '—'} | ${r.videoKbps} kbps | ${r.sizeMB} MB | ${r.sizeRatio}% | ${r.encodeSec}s | ${Number(r.fpsEnc).toFixed(2)} | ${r.framesOk === 'OK' ? '一致' : '不一致'} | ${r.maxPtsErrMs} ms |`);
  }
  lines.push('');
  lines.push('## 画质（原片同帧为参考，全分辨率）');
  lines.push('');
  lines.push('| 版本 | PSNR 均值 | PSNR 最低 | SSIM 均值 | VMAF 4K 均值 | VMAF p5 | VMAF 最低 |');
  lines.push('|---|---|---|---|---|---|---|');
  for (const r of mine.sort((a, b) => orderOf(a.label) - orderOf(b.label))) {
    lines.push(`| ${r.label} | ${f3(r.psnrAvg)} | ${f3(r.psnrMin)} | ${r.ssimAvg} | ${f3(r.vmafAvg)} | ${f3(r.vmafP5)} | ${f3(r.vmafMin)} |`);
  }
  lines.push('');
  lines.push('> VMAF 使用 `vmaf_4k_v0.6.1` 模型、原生分辨率、逐帧计算，未缩放；PSNR/SSIM 为全分辨率逐帧值。');
  lines.push('');
  if (p) {
    lines.push('## 截图清单');
    lines.push('');
    lines.push('| 编号 | 帧号 | 选区时间 | 选取原因 | 局部裁剪 |');
    lines.push('|---|---|---|---|---|');
    for (const f of p.frames) {
      lines.push(`| ${f.fno} | n${f.idx} | ${f.time.toFixed(3)}s | ${f.reason} | ${(f.roi || []).map((r) => `${r.name} (${r.w}×${r.h} @ ${r.x},${r.y})`).join('；') || '—'} |`);
    }
    lines.push('');
    lines.push('每个时刻均包含 原片 与全部编码版本的同一显示帧，文件名为 `帧号_策略_full.png`；局部裁剪为 1:1 像素，同坐标同尺寸。');
    lines.push('');
  }
  lines.push('## 需要人工确认的点');
  lines.push('');
  for (const n of p?.watch || []) lines.push(`- ${n}`);
  lines.push('');
  lines.push('> 本文件只汇总机器可测的结果。观感、闪烁、涂抹与运动表现请直接查看 `编码结果/` 中的视频与截图，本实验未代为判定。');
  lines.push('');

  const dir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
  await fs.writeFile(path.join(dir, '复审说明.md'), lines.join('\n'), 'utf8');
  console.log('写出', path.join(dir, '复审说明.md'));
}
