/**
 * 共用工具：调用项目随附的 ffmpeg / exiftool，读取逐帧时间轴。
 * 编码参数严格复制自 视频压缩脚本/server.mjs 的 buildFfmpegArgs 与 restoreDate，
 * 仅额外加入实验所需的输入区间（-ss / -frames:v）与编码器替换。
 */
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';

export const ROOT = 'E:\\VideoEdit\\一些工具或者脚本\\用于视频压缩算法比对';
export const TOOL = 'E:\\VideoEdit\\一些工具或者脚本\\视频压缩脚本（压缩后会保留原拍摄时间）';
export const FF = path.join(TOOL, 'ffmpeg', 'ffmpeg.exe');
export const ET = path.join(TOOL, 'exiftool', 'exiftool.exe');
export const OUT = path.join(ROOT, 'out');
export const LOGS = path.join(ROOT, 'logs');
export const METRICS = path.join(ROOT, 'metrics');
export const SCRATCH = path.join(ROOT, 'scratch');

const tl = await import(pathToFileURL(path.join(TOOL, 'video-timeline.mjs')).href);
export const readVideoTimeline = tl.readVideoTimeline;
export const verifyVideoTimeline = tl.verifyVideoTimeline;

/** 复用项目做法：去掉 locale 变量，避免 exiftool 的 perl 告警污染输出。 */
export function cleanEnv() {
  const env = { ...process.env };
  delete env.LC_ALL; delete env.LANG; delete env.LANGUAGE;
  return env;
}

export function run(exe, args, opts = {}) {
  return new Promise((resolve) => {
    const started = Date.now();
    const cp = spawn(exe, args, { windowsHide: true, env: cleanEnv(), cwd: opts.cwd });
    let stdout = '', stderr = '', outBytes = 0;
    cp.stdout.on('data', (d) => {
      stdout += d.toString('utf8');
      outBytes += d.length;
      if (opts.onStdout) opts.onStdout(d.toString('utf8'));
    });
    cp.stderr.on('data', (d) => { stderr += d.toString('utf8'); });
    cp.on('error', (e) => resolve({ code: -1, error: e.message, stdout, stderr, ms: Date.now() - started, outBytes }));
    cp.on('close', (code) => resolve({ code, stdout, stderr, ms: Date.now() - started, outBytes }));
  });
}

/* ---------------- 探测 ---------------- */

export async function ffmpegInfo(file) {
  const r = await run(FF, ['-hide_banner', '-i', file]);
  const text = r.stderr;
  const info = { duration: 0, video: null, audio: null, raw: text };
  const dm = /Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/.exec(text);
  if (dm) info.duration = (+dm[1]) * 3600 + (+dm[2]) * 60 + parseFloat(dm[3]);
  for (const line of text.split('\n')) {
    const s = line.trim();
    if (!/^Stream #/.test(s)) continue;
    if (s.includes('Video:') && !info.video) {
      const codec = (/Video:\s*([a-zA-Z0-9_]+)/.exec(s) || [])[1] || '';
      const pix = (/(yuv[a-z0-9]+|nv12|nv16|p010le|p016le|gbrp)\b/.exec(s) || [])[1] || '';
      const size = /(\d{2,5})x(\d{2,5})/.exec(s);
      const fps = /([\d.]+)\s*fps/.exec(s);
      const tbr = /([\d.]+)\s*tbr/.exec(s);
      const tbn = /(\d+)\s*tbn/.exec(s);
      const br = /(\d+)\s*kb\/s/.exec(s);
      const colorTag = new RegExp(pix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\(([^)]*)\\)').exec(s);
      let range = '', prim = '', trc = '';
      if (colorTag) {
        const parts = colorTag[1].split(',').map((x) => x.trim());
        for (const p of parts) {
          if (p === 'tv' || p === 'pc') range = p;
          else if (/^bt|^smpte|^bt2020|^arib|^iec/.test(p)) { if (!prim) prim = p; else if (!trc) trc = p; }
        }
      }
      info.video = {
        codec, pixFmt: pix,
        width: size ? Number(size[1]) : 0, height: size ? Number(size[2]) : 0,
        fps: fps ? parseFloat(fps[1]) : 0, tbr: tbr ? parseFloat(tbr[1]) : 0,
        tbn: tbn ? Number(tbn[1]) : 0, bitrate: br ? Number(br[1]) : 0,
        range, prim, trc,
      };
    } else if (s.includes('Audio:') && !info.audio) {
      const codec = (/Audio:\s*([a-zA-Z0-9_]+)/.exec(s) || [])[1] || '';
      const sr = /(\d+)\s*Hz/.exec(s);
      const br = /(\d+)\s*kb\/s/.exec(s);
      const ch = /(stereo|mono|5\.1)/.exec(s);
      info.audio = { codec, sampleRate: sr ? Number(sr[1]) : 0, bitrate: br ? Number(br[1]) : 0, channels: ch ? ch[1] : '' };
    }
  }
  return info;
}

export async function exifJson(files) {
  const r = await run(ET, ['-json', '-G1', '-a', '-s', '-api', 'QuickTimeUTC=1',
    '-time:all', '-Duration', '-ImageSize', '-FileSize', '-Rotation',
    '-ColorPrimaries', '-TransferCharacteristics', '-MatrixCoefficients',
    '-Profile', '-Encoder', ...files]);
  try { return JSON.parse(r.stdout); } catch { return []; }
}

const COLOR_PRIM = { 'BT.709': 'bt709', 'BT.2020': 'bt2020', 'BT.601': 'bt470bg', 'SMPTE 170M': 'smpte170m', 'Display P3': 'smpte432', 'P3D65': 'smpte432' };
const COLOR_TRC = { 'BT.709': 'bt709', 'BT.2020 (10-bit)': 'bt2020-10', 'BT.2020 (12-bit)': 'bt2020-12', 'SMPTE ST 2084': 'smpte2084', 'ARIB STD-B67': 'arib-std-b67', 'BT.601': 'smpte170m', 'SMPTE 170M': 'smpte170m' };
const COLOR_MATRIX = { 'BT.709': 'bt709', 'BT.2020 non-constant': 'bt2020nc', 'BT.2020 constant': 'bt2020c', 'BT.601': 'smpte170m', 'SMPTE 170M': 'smpte170m' };

/** 与 server.mjs inspect() 相同的色彩/时间解析口径。 */
export async function probe(file) {
  const [fi, ex] = await Promise.all([ffmpegInfo(file), exifJson([file])]);
  const j = ex[0] || {};
  const v = fi.video || {};
  const keysDate = j['Keys:CreationDate'] || '';
  const qtDate = j['QuickTime:CreateDate'] || '';
  const st = await fs.stat(file);
  return {
    path: path.resolve(file),
    name: path.basename(file),
    size: st.size,
    duration: fi.duration,
    width: v.width, height: v.height, pixFmt: v.pixFmt, fps: v.fps, tbr: v.tbr, tbn: v.tbn,
    vBitrate: v.bitrate, codec: v.codec,
    range: v.range, prim: COLOR_PRIM[j['QuickTime:ColorPrimaries']] || v.prim || 'bt709',
    trc: COLOR_TRC[j['QuickTime:TransferCharacteristics']] || v.trc || 'bt709',
    matrix: COLOR_MATRIX[j['QuickTime:MatrixCoefficients']] || 'bt709',
    rawPrim: j['QuickTime:ColorPrimaries'] || '', rawTrc: j['QuickTime:TransferCharacteristics'] || '',
    rawMatrix: j['QuickTime:MatrixCoefficients'] || '',
    rotation: Number(j['QuickTime:Rotation'] || j['Composite:Rotation'] || 0) || 0,
    audio: fi.audio,
    dateRaw: keysDate || qtDate,
    keysDate, qtDate,
    qtCreate: j['QuickTime:CreateDate'] || '', qtModify: j['QuickTime:ModifyDate'] || '',
    qtTrackCreate: j['Track1:TrackCreateDate'] || j['Track:TrackCreateDate'] || '',
    qtMediaCreate: j['Track1:MediaCreateDate'] || j['Track:MediaCreateDate'] || '',
    qtTrack2Create: j['Track2:TrackCreateDate'] || '',
    qtDuration: j['QuickTime:Duration'] || '',
    encColor: [j['Track1:ColorPrimaries'], j['Track1:TransferCharacteristics'], j['Track1:MatrixCoefficients']].filter(Boolean).join('/'),
    fileCreate: j['System:FileCreateDate'] || j['File:FileCreateDate'] || '',
    fileModify: j['System:FileModifyDate'] || j['File:FileModifyDate'] || '',
    encoderTag: j['QuickTime:Encoder'] || '',
  };
}

/** 逐帧时间轴统计：帧数、时间基、唯一帧间隔分布、首末时间。 */
export async function timelineStats(file) {
  const t = await readVideoTimeline(file);
  if (!t) return null;
  const round = (x) => Math.round(x * 1e6) / 1e6;
  const hist = new Map();
  for (let i = 1; i < t.count; i++) {
    const d = round(t.pts[i] - t.pts[i - 1]);
    hist.set(d, (hist.get(d) || 0) + 1);
  }
  const deltas = [...hist.entries()].sort((a, b) => b[1] - a[1]);
  return {
    count: t.count,
    timescale: t.timescale,
    first: round(t.pts[0]),
    last: round(t.pts[t.count - 1]),
    span: round(t.pts[t.count - 1] - t.pts[0]),
    uniqueDeltas: deltas.length,
    topDeltas: deltas.slice(0, 8).map(([d, n]) => ({ delta: d, n })),
    pts: t.pts,
  };
}

/* ---------------- 编码参数（复制自 server.mjs） ---------------- */

export function keyintFor(fps) {
  const f = fps || 30;
  return { keyint: Math.max(24, Math.round(f)), minKeyint: Math.max(12, Math.round(f / 2)) };
}

/**
 * 生成与现有脚本一致的参数序列。
 * variant: { encoder:'x265'|'nvenc', preset, crf?, bitrateK?, extra:string[] }
 */
export function buildArgs(info, src, dst, variant, seg) {
  const args = ['-y', '-hide_banner', '-loglevel', 'error', '-progress', 'pipe:1', '-nostats'];
  if (seg && seg.start > 0) args.push('-ss', seg.start.toFixed(6));
  args.push('-i', src);
  if (seg && seg.frames) args.push('-frames:v', String(seg.frames));
  args.push('-map', '0:v:0');
  if (info.audio) args.push('-map', '0:a:0');

  args.push('-fps_mode:v:0', 'passthrough', '-enc_time_base:v:0', '-1');

  if (variant.encoder === 'x265') {
    args.push('-c:v', 'libx265', '-preset', variant.preset);
    if (variant.crf != null) args.push('-crf', String(variant.crf));
  } else {
    args.push('-c:v', 'hevc_nvenc', '-preset', variant.preset, '-tune', 'hq');
    args.push('-rc', 'vbr');
    if (variant.bitrateK) {
      args.push('-b:v', String(variant.bitrateK) + 'k');
      args.push('-maxrate', String(Math.round(variant.bitrateK * 1.5)) + 'k');
      args.push('-bufsize', String(Math.round(variant.bitrateK * 2)) + 'k');
    }
    args.push('-multipass', 'fullres', '-rc-lookahead', '32');
    args.push('-spatial-aq', '1', '-temporal-aq', '1', '-aq-strength', '8');
    // 实测：b_ref_mode=middle/each 会让可变帧率素材的逐帧时间戳错位（每 4 帧出现一次 22µs+66ms），
    // 关闭“B 帧作参考”后帧数与时间戳均与原片一致，仍保留 3 个连续 B 帧。
    args.push('-bf', '3', '-b_ref_mode', 'disabled', '-nonref_p', '0');
  }

  if (info.is10bit || info.isHDR) args.push('-pix_fmt', 'yuv420p10le', '-profile:v', 'main10');
  else args.push('-pix_fmt', 'yuv420p', '-profile:v', 'main');

  args.push('-color_primaries', info.prim, '-color_trc', info.trc, '-colorspace', info.matrix);

  const { keyint, minKeyint } = keyintFor(info.fps);
  const gop = [`keyint=${keyint}`, `min-keyint=${minKeyint}`, 'log-level=error',
    `colorprim=${info.prim}`, `transfer=${info.trc}`, `colormatrix=${info.matrix}`];
  if (variant.encoder === 'x265') {
    args.push('-x265-params', gop.join(':'));
  } else {
    args.push('-g', String(keyint), '-keyint_min', String(minKeyint));
  }

  args.push('-tag:v', 'hvc1');

  if (info.audio) {
    const ok = ['aac', 'mp3', 'alac', 'ac3', 'eac3'].includes((info.audio.codec || '').toLowerCase());
    if (ok) args.push('-c:a', 'copy');
    else args.push('-c:a', 'aac', '-b:a', '192k');
  }

  if (variant.extra) args.push(...variant.extra);
  args.push(dst);
  return args;
}

/** 复制 server.mjs restoreDate：把原片拍摄时间写回输出。 */
export async function restoreDate(srcMeta, dst) {
  const raw = srcMeta.dateRaw || '';
  if (!raw) return { ok: false, error: '原片没有拍摄时间，跳过' };
  let tz = '+08:00';
  const tm = /([+-]\d{2}:\d{2})\s*$/.exec(raw);
  if (tm) tz = tm[1];
  const stamp = raw.replace(/^(\d{4}):(\d{2}):(\d{2})\s+(\d{2}:\d{2}:\d{2}).*$/, '$1:$2:$3 $4');
  if (!/^\d{4}:\d{2}:\d{2} \d{2}:\d{2}:\d{2}$/.test(stamp)) return { ok: false, error: '拍摄时间格式无法解析：' + raw };
  const args = ['-charset', 'filename=UTF8', '-@', '-'];
  const lines = [
    '-m', '-overwrite_original', '-api', 'QuickTimeUTC=1',
    `-QuickTime:CreateDate=${stamp}`,
    `-QuickTime:ModifyDate=${stamp}`,
    `-QuickTime:TrackCreateDate=${stamp}`,
    `-QuickTime:TrackModifyDate=${stamp}`,
    `-QuickTime:MediaCreateDate=${stamp}`,
    `-QuickTime:MediaModifyDate=${stamp}`,
    `-Keys:CreationDate=${stamp}${tz}`,
    `-FileCreateDate=${stamp}${tz}`,
    `-FileModifyDate=${stamp}${tz}`,
    dst,
  ];
  const r = await new Promise((resolve) => {
    const cp = spawn(ET, args, { windowsHide: true, env: cleanEnv() });
    let so = '', se = '';
    cp.stdout.on('data', (d) => { so += d.toString('utf8'); });
    cp.stderr.on('data', (d) => { se += d.toString('utf8'); });
    cp.on('close', (code) => resolve({ code, so, se }));
    cp.on('error', (e) => resolve({ code: -1, so: '', se: e.message }));
    cp.stdin.write(lines.join('\n') + '\n');
    cp.stdin.end();
  });
  if (r.code !== 0) return { ok: false, error: (r.se || '').trim().slice(-300) };
  return { ok: true, stamp: stamp + tz };
}

/** 逐帧 PTS 对比（显示顺序，已归一化首帧），返回最大偏差与不一致帧位置。 */
export function comparePts(srcPts, outPts) {
  if (srcPts.length !== outPts.length) {
    return { ok: false, reason: `帧数不一致 ${srcPts.length} vs ${outPts.length}`, maxErr: null };
  }
  let maxErr = 0, at = -1;
  for (let i = 0; i < srcPts.length; i++) {
    const e = Math.abs(srcPts[i] - outPts[i]);
    if (e > maxErr) { maxErr = e; at = i; }
  }
  return { ok: true, maxErr, at };
}

export const fmt = (n, d = 2) => Number(n).toFixed(d);
export function bytesHuman(n) {
  const u = ['B', 'KB', 'MB', 'GB'];
  let i = 0, x = n;
  while (x >= 1024 && i < u.length - 1) { x /= 1024; i++; }
  return `${x.toFixed(i >= 2 ? 2 : 0)}${u[i]}`;
}
export async function ensureDirs() {
  for (const d of [OUT, LOGS, METRICS, SCRATCH]) await fs.mkdir(d, { recursive: true });
}
export function exists(p) { return fsSync.existsSync(p); }
