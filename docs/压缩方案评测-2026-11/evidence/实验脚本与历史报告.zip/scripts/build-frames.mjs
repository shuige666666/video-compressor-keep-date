/** 生成 media/frames.json：每段 5 个复审时刻、选取原因、局部裁剪坐标。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));

/** roi 以画面宽高的比例给出，换算成整数像素，保证所有版本裁剪坐标完全一致。 */
const SPEC = {
  C1: {
    watch: [
      'n24 甩镜时的暗部与运动模糊：注意地面与墙面是否出现块状涂抹、暗部是否被抹平',
      'n50 建筑立面：窗框、栏杆、树叶边缘是否糊成一片；亮窗周围是否出现光晕',
      'n81 与 n50 同一建筑、不同角度，是各版本 VMAF 最低的窗口之一，重点看树叶与暗部墙面',
      'n156 路面：大面积低对比暗部，容易看出色块与噪点被抹除的程度',
      'n281 树干与建筑交界：树干边缘、瓷砖纹理，指标体系里同样属于低分窗口',
    ],
    frames: [
      { idx: 24, reason: '甩镜运动模糊 + 暗部（运动）', roi: [] },
      { idx: 50, reason: '建筑立面、亮窗与树丛（细节/纹理）', roi: [{ name: 'roi01', fx: 0.10, fy: 0.22, fw: 0.55, fh: 0.34, note: '窗框与阳台栏杆' }] },
      { idx: 81, reason: '指标体系最低窗口之一（建筑+树叶，细节）', roi: [] },
      { idx: 156, reason: '路面暗部（低对比、噪点）', roi: [] },
      { idx: 281, reason: '指标体系最低窗口之一（树干+瓷砖，暗部纹理）', roi: [{ name: 'roi01', fx: 0.35, fy: 0.30, fw: 0.45, fh: 0.30, note: '树干边缘与墙面瓷砖' }] },
    ],
  },
  C2: {
    watch: [
      '人群衣物与发丝：密集细节最容易出现糊化，注意白色衣物上的蕾丝与花纹',
      'n86、n205 是各版本 VMAF 最低的两个窗口，重点比较这两处的人物边缘',
      '背景海报与招牌小字是否还能辨认',
      '画面右侧橙色道具的渐变是否出现色带',
    ],
    frames: [
      { idx: 48, reason: '人群全景（人物/衣物细节）', roi: [{ name: 'roi01', fx: 0.30, fy: 0.28, fw: 0.34, fh: 0.40, note: '前景人物衣物与发丝' }] },
      { idx: 86, reason: '指标体系最低窗口之一（人群细节）', roi: [] },
      { idx: 205, reason: '指标体系最低窗口之二（人群细节）', roi: [] },
      { idx: 312, reason: '均匀分布中段（人群/背景招牌）', roi: [{ name: 'roi01', fx: 0.55, fy: 0.10, fw: 0.30, fh: 0.22, note: '背景招牌文字' }] },
      { idx: 552, reason: '均匀分布末段（人群密度变化）', roi: [] },
    ],
  },
  C3: {
    watch: [
      '画面右上“江漁兄”招牌笔画是否粘连、边缘是否出现振铃（左后方另有一块小字招牌“KRA FISH / 工漁兄”）',
      '亮片服装的高频细节与红色饱和区是否出现色块',
      '前景观众头部是大面积暗部，注意暗部层次是否被压平',
      'n329 是各版本 VMAF 最低窗口，人物转身时最易看出拖影',
    ],
    frames: [
      { idx: 48, reason: '均匀分布前段（人物+招牌文字）', roi: [{ name: 'roi01', fx: 0.60, fy: 0.010, fw: 0.385, fh: 0.095, note: '招牌文字' }] },
      { idx: 180, reason: '均匀分布中段（亮片服装细节）', roi: [{ name: 'roi01', fx: 0.28, fy: 0.30, fw: 0.34, fh: 0.30, note: '人物服装与面部' }] },
      { idx: 329, reason: '指标体系最低窗口（人物转身运动）', roi: [] },
      { idx: 445, reason: '均匀分布后段（多人并排）', roi: [] },
      { idx: 553, reason: '末段（人群与暗部前景）', roi: [] },
    ],
  },
  C4: {
    watch: [
      '整段为红光照明，注意红色通道是否被压成色块、暗部是否发灰',
      'n109 衣服上的书法字是最直接的文字判据，看笔画是否还在',
      'n188 大面积红色布幔渐变，最容易出现色带',
      '可变帧率素材：播放时留意是否有节奏突变或卡顿（截图看不出来）',
    ],
    frames: [
      { idx: 29, reason: '地面与地毯纹理（暗部细节）', roi: [] },
      { idx: 69, reason: '指标体系最低窗口（快速运动模糊）', roi: [] },
      { idx: 109, reason: '衣服书法文字（文字判据）', roi: [{ name: 'roi01', fx: 0.24, fy: 0.18, fw: 0.42, fh: 0.34, note: '书法字与衣料纹理' }] },
      { idx: 188, reason: '大面积红色布幔（暗部与渐变）', roi: [] },
      { idx: 296, reason: '多人场景（综合细节）', roi: [{ name: 'roi01', fx: 0.18, fy: 0.12, fw: 0.40, fh: 0.36, note: '人物与灯笼细节' }] },
    ],
  },
  C5: {
    watch: [
      'n1 橙色瓶盖上的环形小字是明确的文字判据，注意笔画是否糊成一片',
      '食物表面的油光与烤纹是高频细节，注意是否被抹平',
      'n180 是甩镜运动模糊，注意拖影方向是否自然',
      '厨房橱柜上的标签小字与不锈钢反光',
    ],
    frames: [
      { idx: 1, reason: '食物特写 + 瓶盖环形文字（纹理/文字）', roi: [{ name: 'roi01', fx: 0.50, fy: 0.66, fw: 0.42, fh: 0.28, note: '瓶盖环形小字' }] },
      { idx: 66, reason: '食物表面油光与烤纹（高频纹理）', roi: [{ name: 'roi01', fx: 0.05, fy: 0.05, fw: 0.55, fh: 0.30, note: '鱼肉与烤盘纹理' }] },
      { idx: 180, reason: '甩镜运动模糊（运动）', roi: [] },
      { idx: 444, reason: '厨房人物与橱柜（室内混合光）', roi: [] },
      { idx: 482, reason: '指标体系最低窗口（锅壁蜂窝纹理与水滴）', roi: [{ name: 'roi01', fx: 0.03, fy: 0.40, fw: 0.40, fh: 0.30, note: '锅壁蜂窝纹理、纸垫与锅沿' }] },
    ],
  },
  C6: {
    watch: [
      'LED 屏上的文字与图标是否保留笔画，色块是否出现马赛克',
      '密集人群与高举的手臂是最难的运动细节，注意手臂边缘是否粘连',
      '舞台灯光的高饱和区域是否出现色带或溢出',
      'n314 是各版本 VMAF 最低窗口',
    ],
    frames: [
      { idx: 48, reason: '均匀分布前段（人群+LED）', roi: [{ name: 'roi01', fx: 0.52, fy: 0.02, fw: 0.30, fh: 0.16, note: 'LED 屏文字' }] },
      { idx: 180, reason: '均匀分布中段（人群运动）', roi: [{ name: 'roi01', fx: 0.20, fy: 0.30, fw: 0.36, fh: 0.36, note: '人群头部与手臂' }] },
      { idx: 314, reason: '指标体系最低窗口（剧烈运动）', roi: [] },
      { idx: 445, reason: '均匀分布后段（手臂密集）', roi: [] },
      { idx: 567, reason: '末段（镜头移动后）', roi: [] },
    ],
  },
};

const out = {};
for (const clip of manifest.clips) {
  const spec = SPEC[clip.id];
  if (!spec) continue;
  const pts = JSON.parse(await fs.readFile(path.join(ROOT, 'media', `pts-${clip.id}.json`), 'utf8'));
  out[clip.id] = {
    watch: spec.watch,
    frames: spec.frames.map((f, i) => ({
      fno: `F${String(i + 1).padStart(2, '0')}`,
      idx: f.idx,
      time: pts[f.idx],
      reason: f.reason,
      roi: (f.roi || []).map((r) => ({
        name: r.name,
        x: Math.round(r.fx * clip.displayWidth / 2) * 2,
        y: Math.round(r.fy * clip.displayHeight / 2) * 2,
        w: Math.round(r.fw * clip.displayWidth / 2) * 2,
        h: Math.round(r.fh * clip.displayHeight / 2) * 2,
        note: r.note,
      })),
    })),
  };
  console.log(clip.id, out[clip.id].frames.map((f) => `${f.fno}=n${f.idx}@${f.time.toFixed(2)}s`).join(' '));
}

await fs.writeFile(path.join(ROOT, 'media', 'frames.json'), JSON.stringify(out, null, 2), 'utf8');
console.log('已写 media/frames.json');
