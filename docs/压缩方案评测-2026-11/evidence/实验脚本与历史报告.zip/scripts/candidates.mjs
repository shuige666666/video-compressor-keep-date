/** 内部勘察：按候选帧列表抽取小图，仅用于挑选复审时刻，不进入交付目录。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, FF, run, SCRATCH } from './lib.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
const CAND = {
  C1: [24, 50, 81, 90, 156, 165, 206, 222, 277, 281],
  C2: [48, 86, 180, 205, 312, 325, 386, 444, 447, 552],
  C3: [0, 48, 180, 312, 329, 390, 445, 505, 553, 566],
  C4: [29, 69, 109, 176, 188, 224, 268, 296, 333, 361],
  C5: [1, 48, 66, 180, 312, 421, 444, 482, 543, 552],
  C6: [48, 180, 253, 312, 314, 444, 445, 506, 552, 567],
};

for (const clip of manifest.clips) {
  const list = CAND[clip.id];
  if (!list) continue;
  const outDir = path.join(SCRATCH, 'cand', clip.id);
  await fs.rm(outDir, { recursive: true, force: true });
  await fs.mkdir(outDir, { recursive: true });
  const expr = list.map((i) => `eq(n\\,${i})`).join('+');
  const r = await run(FF, ['-y', '-hide_banner', '-loglevel', 'error',
    '-ss', Math.max(0, clip.segment.startPts - 0.0005).toFixed(6), '-i', clip.src,
    '-vf', `select='${expr}',scale=380:-2`, '-fps_mode:v', 'passthrough',
    '-frames:v', String(list.length), '-f', 'image2', '-start_number', '1',
    path.join(outDir, 'c%02d.png')]);
  console.log(clip.id, r.code === 0 ? 'ok' : r.stderr.slice(-200), list.map((n, i) => `c${String(i + 1).padStart(2, '0')}=n${n}`).join(' '));
}
