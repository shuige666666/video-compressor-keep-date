/** 汇总：把 logs/ 与 metrics/ 的逐条结果合并成 CSV，并输出报告用数据。 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { ROOT, LOGS, METRICS, ensureDirs } from './lib.mjs';
import { readSampleSizes } from './samples.mjs';

const manifest = JSON.parse(await fs.readFile(path.join(ROOT, 'media', 'manifest.json'), 'utf8'));
await ensureDirs();

const ORDER = ['x265_medium_crf22', 'x265_fast_crf22', 'x265_medium_crf24', 'x265_fast_crf24', 'nvenc_p7_eq_medium22', 'nvenc_p7_eq_medium24'];
const sortKey = (l) => {
  const i = ORDER.findIndex((x) => l.startsWith(x));
  return i < 0 ? 100 + l : i;
};

const rows = [];
for (const clip of manifest.clips) {
  const sizes = await readSampleSizes(clip.src);
  const segBytes = sizes ? sizes.slice(clip.segment.startIdx, clip.segment.startIdx + clip.segment.frames).reduce((a, b) => a + b, 0) : null;
  const clipDir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
  const encDir = path.join(clipDir, '编码结果');
  const labels = (await fs.readdir(encDir)).filter((f) => f.endsWith('.mp4')).map((f) => path.basename(f, '.mp4')).sort((a, b) => sortKey(a) - sortKey(b));

  for (const label of labels) {
    let rec;
    try { rec = JSON.parse(await fs.readFile(path.join(LOGS, `${clip.id}-${label}.json`), 'utf8')); } catch { continue; }
    let met = null;
    try { met = JSON.parse(await fs.readFile(path.join(METRICS, `${clip.id}-${label}.json`), 'utf8')); } catch { met = null; }
    rows.push({
      clip: clip.id, clipName: clip.srcName, scene: clip.scene,
      label, encoder: rec.encoder, preset: rec.preset, crf: rec.crf ?? '',
      targetKbps: rec.targetBitrateK ?? '',
      videoKbps: rec.videoKbps, audioKbps: rec.audioKbps,
      sizeBytes: rec.outBytes, sizeMB: +(rec.outBytes / 1e6).toFixed(2),
      srcSegBytes: segBytes, sizeRatio: segBytes ? +(rec.outBytes / segBytes * 100).toFixed(1) : '',
      encodeSec: +(rec.encodeMs / 1000).toFixed(1), totalSec: +(rec.totalMs / 1000).toFixed(1),
      frames: rec.frameCheck.outFrames, framesOk: rec.frameCheck.ok ? 'OK' : 'FAIL',
      maxPtsErrMs: +((rec.frameCheck.maxPtsErr ?? 0) * 1000).toFixed(4),
      dateRestored: rec.dateRestore?.ok ? 'OK' : 'FAIL',
      outW: rec.out.width, outH: rec.out.height, outRot: rec.out.rotation,
      psnrAvg: met ? +met.psnr.avg.toFixed(3) : '', psnrMin: met ? +met.psnr.min.toFixed(3) : '',
      ssimAvg: met ? +met.ssim.avg.toFixed(5) : '',
      vmafAvg: met ? +met.vmaf.avg.toFixed(2) : '', vmafP5: met ? +met.vmaf.p5.toFixed(2) : '', vmafMin: met ? +met.vmaf.min.toFixed(2) : '',
      fpsEnc: +(rec.frameCheck.outFrames / (rec.encodeMs / 1000)).toFixed(2),
      bpp: +((rec.videoKbps * 1000) / (clip.displayWidth * clip.displayHeight * (clip.segment.frames / clip.segment.duration))).toFixed(4),
    });
  }
}

const header = Object.keys(rows[0]);
const csv = [header.join(','), ...rows.map((r) => header.map((h) => {
  const v = r[h] ?? '';
  return typeof v === 'string' && /[",\n]/.test(v) ? `"${v.replace(/"/g, '""')}"` : v;
}).join(','))].join('\r\n');

await fs.mkdir(path.join(ROOT, 'report'), { recursive: true });
await fs.writeFile(path.join(ROOT, 'report', '汇总.csv'), '\ufeff' + csv, 'utf8');

// 每段视频自己的 CSV
for (const clip of manifest.clips) {
  const mine = rows.filter((r) => r.clip === clip.id);
  if (!mine.length) continue;
  const h = Object.keys(mine[0]);
  const body = [h.join(','), ...mine.map((r) => h.map((x) => r[x] ?? '').join(','))].join('\r\n');
  const dir = path.join(ROOT, 'results', `${clip.id}_${path.basename(clip.srcName, '.mp4')}`);
  await fs.writeFile(path.join(dir, '本视频结果.csv'), '\ufeff' + body, 'utf8');
}

await fs.writeFile(path.join(ROOT, 'report', 'data.json'), JSON.stringify(rows, null, 2), 'utf8');
console.log(`汇总 ${rows.length} 条 → report/汇总.csv`);
console.table(rows.map((r) => ({ clip: r.clip, label: r.label, MB: r.sizeMB, '%': r.sizeRatio, s: r.encodeSec, PSNR: r.psnrAvg, VMAF: r.vmafAvg, ok: r.framesOk })));
