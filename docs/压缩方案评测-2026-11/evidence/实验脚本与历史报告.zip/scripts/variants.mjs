/** 编码版本定义。标签同时用于文件名与报告。 */
export const VARIANTS = {
  A: { key: 'A', label: 'x265_medium_crf22', encoder: 'x265', preset: 'medium', crf: 22, desc: 'x265 medium CRF22（现有工具默认档）' },
  B: { key: 'B', label: 'x265_fast_crf22', encoder: 'x265', preset: 'fast', crf: 22, desc: 'x265 fast CRF22' },
  C: { key: 'C', label: 'x265_medium_crf24', encoder: 'x265', preset: 'medium', crf: 24, desc: 'x265 medium CRF24' },
  D: { key: 'D', label: 'x265_fast_crf24', encoder: 'x265', preset: 'fast', crf: 24, desc: 'x265 fast CRF24' },
  E: { key: 'E', label: 'nvenc_p7_eq_medium22', encoder: 'nvenc', preset: 'p7', targetFrom: 'A', desc: 'NVENC p7，按 A 实际视频码率校准' },
  F: { key: 'F', label: 'nvenc_p7_eq_medium24', encoder: 'nvenc', preset: 'p7', targetFrom: 'C', desc: 'NVENC p7，按 C 实际视频码率校准' },
  // 第二轮补测
  G: { key: 'G', label: 'nvenc_p5_eq_medium22', encoder: 'nvenc', preset: 'p5', targetFrom: 'A', desc: 'NVENC p5，与 E 同码率' },
  H: { key: 'H', label: 'nvenc_p7_bitrate120', encoder: 'nvenc', preset: 'p7', targetFrom: 'A', desc: 'NVENC p7，码率取 A 的 1.2 倍' },
  I: { key: 'I', label: 'x265_slow_crf22', encoder: 'x265', preset: 'slow', crf: 22, desc: 'x265 slow CRF22（计算量换画质的参考）' },
  J: { key: 'J', label: 'x265_medium_crf26', encoder: 'x265', preset: 'medium', crf: 26, desc: 'x265 medium CRF26（小体积档参考）' },
  K: { key: 'K', label: 'x265_fast_crf21', encoder: 'x265', preset: 'fast', crf: 21, desc: 'x265 fast CRF21（验证 fast 补一点点码率能否追平 medium CRF22）' },
};
