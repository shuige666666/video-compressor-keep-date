/**
 * 第二轮与复测：速度复测（交错顺序）+ NVENC p5/p7 + x265 slow + CRF26 参考。
 * 全部仍为单任务串行，复测结果写 scratch，不进入交付的编码结果目录。
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { ROOT, LOGS, SCRATCH } from './lib.mjs';

const P = path.join(ROOT, 'scripts', 'encode.mjs');
const run = (args) => new Promise((res, rej) => {
  const cp = spawn(process.execPath, [P, ...args], { cwd: ROOT, stdio: ['ignore', 'pipe', 'pipe'] });
  let err = '';
  cp.stdout.on('data', (d) => process.stdout.write(d));
  cp.stderr.on('data', (d) => { err += d.toString(); });
  cp.on('close', (c) => (c === 0 ? res() : rej(new Error(err.slice(-300)))));
});

const rec = async (clip, label) => JSON.parse(await fs.readFile(path.join(LOGS, `${clip}-${label}.json`), 'utf8'));

const REPEAT = path.join(SCRATCH, 'repeat');
const JOBS = [
  // 速度复测：先 B 后 A，与首次相反的顺序，抵消冷热机顺序偏差
  { clip: 'C6', variant: 'B', outDir: REPEAT, tag: 'rep2' },
  { clip: 'C6', variant: 'A', outDir: REPEAT, tag: 'rep2' },
  { clip: 'C2', variant: 'B', outDir: REPEAT, tag: 'rep2' },
  { clip: 'C2', variant: 'A', outDir: REPEAT, tag: 'rep2' },
  // 补测：p5 与 p7 同码率
  { clip: 'C1', variant: 'G', bitrateFrom: 'x265_medium_crf22' },
  { clip: 'C6', variant: 'G', bitrateFrom: 'x265_medium_crf22' },
  // 补测：x265 slow 与更小体积档
  { clip: 'C1', variant: 'I' },
  { clip: 'C6', variant: 'J' },
];

for (const job of JOBS) {
  const args = ['--clip', job.clip, '--variant', job.variant];
  if (job.outDir) args.push('--outDir', job.outDir);
  if (job.tag) args.push('--tag', job.tag);
  if (job.bitrateFrom) {
    const ref = await rec(job.clip, job.bitrateFrom);
    args.push('--bitrateK', String(ref.videoKbps));
    console.log(`\n[${job.clip}/${job.variant}] 目标 ${ref.videoKbps}kbps（来自 ${job.bitrateFrom}）`);
  }
  await run(args);
  // NVENC 校准偏差过大时修正一次
  if (job.variant === 'G') {
    const label = job.variant === 'G' ? `nvenc_p5_eq_medium22` : '';
    const r = JSON.parse(await fs.readFile(path.join(LOGS, `${job.clip}-${label}.json`), 'utf8'));
    const target = Number(args[args.length - 2]);
    if (Math.abs(r.videoKbps / target - 1) > 0.05) {
      const adj = Math.round(target * (target / r.videoKbps));
      console.log(`  偏差 ${((r.videoKbps / target - 1) * 100).toFixed(1)}% → 修正为 ${adj}kbps`);
      await run(['--clip', job.clip, '--variant', job.variant, '--bitrateK', String(adj)]);
    }
  }
}
console.log('\n补测完成');
